using System;
using System.Collections.Generic;

namespace Test1
{
    class Test34
    {
        public void Test()
        {
            StorageIDManager manager = StorageIDManager.GetInstance(p_maxBoxId: 15, p_maxCabinetId: 2);
            StorageCabinet cabinet1 = StorageCabinet.GetStorageCabinet(manager, 5);
            StorageCabinet cabinet2 = StorageCabinet.GetStorageCabinet(manager, 5);
            StorageBox box1 = StorageBox.GetInstance(manager, cabinet1);
            StorageBox box2 = StorageBox.GetInstance(manager, cabinet1);
            StorageBox box3 = StorageBox.GetInstance(manager, cabinet1);
            StorageBox box4 = StorageBox.GetInstance(manager, cabinet2);
            StorageBox box5 = StorageBox.GetInstance(manager, cabinet2);
            StorageBox box6 = StorageBox.GetInstance(manager, cabinet2);
            StorageBox box7 = StorageBox.GetInstance(manager, cabinet2);
            cabinet1.Store();
            cabinet2.Store();
            cabinet1.TakeOut();
            cabinet2.TakeOut();
        }

        /*
        享元模式多用于对象池的构建，当我们需要获取某个对象实例时，往往是通过new的方式，这种方式就可能带来较大的资源开销，
        通过享元模式我们可以先创建指定数量的对象实例，然后提供一个获取实例的方法，如果提前创建的对象实例存在空闲的则直接返回
        空闲的对象实例，若没有则可以创建一个新的对象实例。我们这里有存储柜和存储盒，存储柜中可以包括多个存储盒，当我们指定
        了存储柜的规格时，默认先创建指定容量的一半的存储盒，当获取存储盒实例时，如果存在空闲的存储盒则直接返回，否则创建一个
        新的存储盒，并且把数量上限+5，但是依旧小于指定容量，当存储盒数量达到指定容量时，再次获取存储盒实例时，若无空闲存储盒则
        依然是创建一个新的存储盒实例，然后指定容量+1。
        */
    }

    //存储盒，继承StorageObject
    class StorageBox : StorageObject
    {
        public bool isUsed;
        private StorageBox(StorageIDManager p_manager) : base(p_manager)
        {
            id = idManager.GetBoxId();
        }

        public static StorageBox GetInstance(StorageIDManager p_manager, StorageCabinet p_cabinet)
        {
            p_cabinet.Add(new StorageBox(p_manager));
            return p_cabinet.GetStorageBox();
        }
        public override void Store()
        {
            if (isEmpty)
            {
                Console.WriteLine("[StorageBox:" + id + "]:Some things are stored in the box.");
                isEmpty = false;
            }
            else Console.WriteLine("[StorageBox:" + id + "]:The box is being used.");
        }

        public override void TakeOut()
        {
            if (!isEmpty)
            {
                Console.WriteLine("[StorageBox:" + id + "]:The things of the box have been taken out.");
                isEmpty = true;
            }
            else Console.WriteLine("[StorageBox:" + id + "]:There is nothing in the box.");
        }
    }

    //存储柜，继承StorageObject
    class StorageCabinet : StorageObject
    {
        private int capacity;
        private int count;
        private List<StorageBox> boxes = new List<StorageBox>();
        private int index = 0;
        private StorageCabinet(StorageIDManager p_manager, int p_capacity = 10) : base(p_manager)
        {
            if (p_capacity != 10) capacity = p_capacity;
            count = capacity / 2;
            for (int i = 0; i < count; i++)
            {
                StorageBox.GetInstance(idManager, this);
            }
            id = idManager.GetCabinetId();
        }

        public static StorageCabinet GetStorageCabinet(StorageIDManager p_manager, int p_capacity = 10)
        {
            return new StorageCabinet(p_manager, p_capacity);
        }

        public StorageBox GetStorageBox()
        {
            foreach (StorageBox b in boxes)
            {
                if (b.isEmpty && !b.isUsed)
                {
                    b.isUsed = true;
                    return b;
                }
            }
            capacity++;
            return StorageBox.GetInstance(idManager, this);
        }

        public void Add(StorageBox p_box)
        {
            if (index < count)
            {
                boxes.Add(p_box);
                index++;
            }
            else if (count + 5 < capacity)
            {
                count += 5;
                Add(p_box);
            }
            else if (count < capacity)
            {
                count = capacity;
                Add(p_box);
            }
        }

        public override void Store()
        {
            bool isStore = false;
            Console.WriteLine("【StorageCabinet:" + id + "】---Store");
            Console.WriteLine("-------------------------------------------------");
            foreach (StorageBox b in boxes)
            {
                if (b.isEmpty)
                {
                    isStore = true;
                    b.Store();
                }
            }
            if (!isStore) Console.WriteLine("The StorageCabinet has no empty box.");
            Console.WriteLine("-------------------------------------------------\n");
        }

        public override void TakeOut()
        {
            bool isTakeOut = false;
            Console.WriteLine("【StorageCabinet:" + id + "】---TakeOut");
            Console.WriteLine("-------------------------------------------------");
            foreach (StorageBox b in boxes)
            {
                if (!b.isEmpty)
                {
                    isTakeOut = true;
                    b.TakeOut();
                }
            }
            if (!isTakeOut) Console.WriteLine("There is nothing in the StorageCabinet to take out.");
            Console.WriteLine("-------------------------------------------------\n");
        }
    }

    //存储对象的唯一标识ID，ID管理器
    public class StorageIDManager
    {
        public int maxBoxId;
        public int minBoxId;
        private static int boxId;
        public int maxCabinetId;
        public int minCabinetId;
        private static int cabinetId;

        private StorageIDManager(int p_minBoxId, int p_maxBoxId, int p_minCabinetId, int p_maxCabinetId)
        {
            minBoxId = p_minBoxId;
            maxBoxId = p_maxBoxId;
            boxId = minBoxId;
            minCabinetId = p_minCabinetId;
            maxCabinetId = p_maxCabinetId;
            cabinetId = minCabinetId;
        }
        private class IDManagerHandler
        {
            public static StorageIDManager instance = new StorageIDManager(1, 10, 1, 5);
        }

        public static StorageIDManager GetInstance(int p_minBoxId = 1, int p_maxBoxId = 10, int p_minCabinetId = 1, int p_maxCabinetId = 5)
        {
            bool isBoxCapacityChange = false;
            bool isCabinetCapacityChange = false;
            if ((p_minBoxId != 1 || p_maxBoxId != 10) && p_minBoxId > 0 && p_minBoxId < p_maxBoxId)
            {
                isBoxCapacityChange = true;
                boxId = p_minBoxId;
            }
            if ((p_minCabinetId != 1 || p_maxCabinetId != 5) && p_minCabinetId > 0 && p_minCabinetId < p_maxCabinetId)
            {
                isCabinetCapacityChange = true;
                cabinetId = p_minCabinetId;
            }
            if (isBoxCapacityChange || isCabinetCapacityChange)
                IDManagerHandler.instance = new StorageIDManager(p_minBoxId, p_maxBoxId, p_minCabinetId, p_maxCabinetId);
            return IDManagerHandler.instance;
        }

        public int GetBoxId()
        {
            if (boxId >= minBoxId && boxId <= maxBoxId) return boxId++;
            else return -1;
        }

        public int GetCabinetId()
        {
            if (cabinetId >= minCabinetId && cabinetId <= maxCabinetId) return cabinetId++;
            else return -1;
        }
    }

    //所有存储对象继承该抽象类
    public abstract class StorageObject
    {
        public int id;
        public bool isEmpty = true;
        protected StorageIDManager idManager;
        public StorageObject(StorageIDManager p_manager) { idManager = p_manager; }
        public abstract void Store();
        public abstract void TakeOut();
    }
}