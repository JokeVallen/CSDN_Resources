using System;

namespace Test1
{
    class Main
    {
        static void Main(string[] args)
        {
            //1-24:Singleton模式
            // Test24 t24 = new Test24();
            // t24.Test();

            //1-25:Factory模式
            // Test25 t25 = new Test25();
            // t25.Test();

            //1-27:Strategy模式
            // Test27 t27 = new Test27();
            // t27.Test();

            //1-28:Facade模式
            // Test28 t28 = new Test28();
            // t28.Test();

            //1-29:Mediator模式
            // Test29 t29 = new Test29();
            // t29.Test();

            //1-30:Decorator模式
            // Test30 t30 = new Test30();
            // t30.Test();

            //1-31:COR模式
            // Test31 t31 = new Test31();
            // t31.Test();

            //1-32:Observer模式
            // Test32 t32 = new Test32();
            // t32.Test();

            //1-33:Composite模式
            // Test33 t33 = new Test33();
            // t33.Test();

            //1-34:Flyweight模式
            // Test34 t34 = new Test34();
            // t34.Test();

            //1-35:Proxy模式
            // Test35 t35 = new Test35();
            // t35.Test();

            //1-36:Iterator模式
            // Test36 t36 = new Test36();
            // t36.Test();

            //1-37:Visitor模式
            // Test37 t37 = new Test37();
            // t37.Test();

            //1-38:Builder模式
            // Test38 t38 = new Test38();
            // t38.Test();

            //1-39:Adapter模式
            // Test39 t39 = new Test39();
            // t39.Test();

            //1-40:Bridge模式
            // Test40 t40 = new Test40();
            // t40.Test();

            //1-41:Command模式
            // Test41 t41 = new Test41();
            // t41.Test();

            //1-42:Prototype模式
            // Test42 t42 = new Test42();
            // t42.Test();

            //1-43:Memento模式
            // Test43 t43 = new Test43();
            // t43.Test();

            //1-44:TemplateMethod模式
            // Test44 t44 = new Test44();
            // t44.Test();

            //1-45:State模式
            // Test45 t45 = new Test45();
            // t45.Test();
        }
    }
}