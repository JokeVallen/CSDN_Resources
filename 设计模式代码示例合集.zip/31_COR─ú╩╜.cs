using System.Collections.Generic;
using System;

namespace Test1
{
    class Test31
    {
        public void Test()
        {
            LevelCondition levelConditon = new LevelCondition("等级条件");
            AchievementCondition achievementCondition = new AchievementCondition("成就条件");
            TaskCondition taskCondition = new TaskCondition("任务条件");
            ConditionChain conditionChain = new ConditionChain();
            ConditionChain chain = new ConditionChain();
            conditionChain.Add(levelConditon);
            conditionChain.Add(achievementCondition);
            chain.Add(taskCondition);
            conditionChain.Add(chain);
            Player kaka = new Player("Kaka", 33, 30, 55);
            Player jojo = new Player("JoJo", 25, 30, 30);

            Console.WriteLine("【KaKa】");
            var res = conditionChain.Judge(kaka);
            Console.WriteLine("IsPass:" + res);
            Console.WriteLine("【JoJo】");
            res = conditionChain.Judge(jojo);
            Console.WriteLine("IsPass:" + res);
        }
        /*
        责任链模式，通常用于对一个对象的多种分步处理，例如对于用户输入的信息在保存至DB前进行筛选和替换，
        或者一个游戏活动要求判断玩家等级、成就、任务达到要求才能领取奖励等等，责任链可以自由添加和删除
        处理流程，并且还支持将责任链作为添加和删除的对象，简而言之就是责任链之间也可以进行连接。当然还有
        更复杂的责任链模式结合递归，例如Java中的Filter。
        */
    }

    //等级条件，继承Condition
    public class LevelCondition : Condition
    {
        public LevelCondition(string p_name)
        {
            name = p_name;
        }

        public override bool Judge(Player p_player)
        {
            if (p_player.level < 25)
            {
                Console.WriteLine("The player " + p_player.name + " not meets level condition.");
                return false;
            }
            Console.WriteLine("The player " + p_player.name + " meets level condition.");
            return true;
        }
    }

    //成就条件，继承Condition
    public class AchievementCondition : Condition
    {
        public AchievementCondition(string p_name)
        {
            name = p_name;
        }

        public override bool Judge(Player p_player)
        {
            if (p_player.achievement < 30)
            {
                Console.WriteLine("The player " + p_player.name + " not meets achievement condition.");
                return false;
            }
            Console.WriteLine("The player " + p_player.name + " meets achievement condition.");
            return true;
        }
    }

    //任务条件，继承Condition
    public class TaskCondition : Condition
    {
        public TaskCondition(string p_name)
        {
            name = p_name;
        }

        public override bool Judge(Player p_player)
        {
            if (p_player.task < 50)
            {
                Console.WriteLine("The player " + p_player.name + " not meets task condition.");
                return false;
            }
            Console.WriteLine("The player " + p_player.name + " meets task condition.");
            return true;
        }
    }

    //抽象条件，实现ICondition接口
    public abstract class Condition : ICondition
    {
        protected string name;

        public abstract bool Judge(Player p_player);
    }

    //条件和条件链需要实现该接口
    public interface ICondition
    {
        public bool Judge(Player p_player);
    }

    //条件链，实现ICondition接口
    public class ConditionChain : ICondition
    {
        private List<ICondition> conditionChain = new List<ICondition>();

        public void Add(ICondition p_condition)
        {
            conditionChain.Add(p_condition);
        }

        public bool Judge(Player p_player)
        {
            foreach (ICondition c in conditionChain)
            {
                if (!c.Judge(p_player)) return false;
            }
            return true;
        }

        public void Remove(ICondition p_condition)
        {
            conditionChain.Remove(p_condition);
        }
    }

    //玩家类
    public class Player
    {
        public string name;
        public int level;
        public int achievement;
        public int task;

        public Player(string p_name, int p_level, int p_achievement, int p_task)
        {
            name = p_name;
            level = p_level;
            achievement = p_achievement;
            task = p_task;
        }
    }
}