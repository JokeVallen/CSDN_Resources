using System;

namespace Test1
{
    class Test42
    {
        public void Test()
        {
            Cube cube1 = new Cube("cube1", "Blue", "Wood", 4, 4, 4, new Position(3.1f, 2.2f, 4.2f));
            Cube cube2 = cube1.Clone();
            cube1.color = "Black";
            cube2.name = "cube2";
            Console.WriteLine(cube1);
            Console.WriteLine(cube2);
            Console.WriteLine(cube1 == cube2);
        }
        /*
        原型模式通常用于克隆一个对象，当一个对象进行创建时需要传递许多参数，但是很多参数我们可以与之前的
        对象保持一致，那么就可以通过原型模式来实现对象克隆。我们要求具备克隆功能的类实现ICloneable接口的
        Clone方法，在Clone方法中对不需要更改的参数进行默认赋值，然后返回一个对象，这样当我们需要克隆一个
        对象时，直接调用其Clone方法即可。
        */
    }

    public class Cube : IConleable<Cube>
    {
        public string name;
        public string color;
        public string material;
        public float width;
        public float height;
        public float length;
        public Position position;

        public Cube(string p_name, string p_color, string p_material, float p_width, float p_height, float p_length, Position p_position)
        {
            name = p_name;
            color = p_color;
            material = p_material;
            width = p_width;
            height = p_height;
            length = p_length;
            position = p_position;
        }
        public Cube Clone()
        {
            Position v_position = new Position(position.x, position.y, position.z);
            return new Cube(name, color, material, width, height, length, v_position);
        }

        public override string ToString()
        {
            string v_str = "";
            v_str += "【Cube:" + name + "】\n";
            v_str += "--------------------------\n";
            v_str += "[Color]:" + color + "\n";
            v_str += "[Material]:" + material + "\n";
            v_str += "[Width]:" + width + "\n";
            v_str += "[Height]:" + height + "\n";
            v_str += "[Length]:" + length + "\n";
            v_str += "--------------------------\n";
            return v_str;
        }
    }

    public class Position
    {
        public float x;
        public float y;
        public float z;
        public Position(float p_x, float p_y, float p_z) { x = p_x; y = p_y; z = p_z; }
    }

    public interface IConleable<T>
    {
        public T Clone();
    }
}