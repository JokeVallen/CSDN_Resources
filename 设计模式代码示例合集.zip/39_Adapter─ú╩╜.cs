using System;

namespace Test1
{
    class Test39
    {
        public void Test()
        {
            AndroidPhone mi12 = new AndroidPhone("小米 12", InterfaceType.USB_TypeC, 13.4f, 5);
            ApplePhone apple13 = new ApplePhone("Apple 13", InterfaceType.Lightning, 1, 5);
            AndroidChargerCable romosChargerCable = new AndroidChargerCable.Builder()
            .BaseInfo("罗马仕CB051-72-113", "TPE", 1.5f, 3)
            .InterfaceType(InterfaceType.USB, InterfaceType.Micro_USB)
            .Build();
            AndroidChargerCable miChargerCable = new AndroidChargerCable.Builder()
            .BaseInfo("小米原装USB-C数据线", "TPE", 1, 6)
            .InterfaceType(InterfaceType.USB, InterfaceType.USB_TypeC)
            .Build();
            AppleChargerCable appleChargerCable = new AppleChargerCable.Builder()
            .BaseInfo("AppleA2244", "TPE", 1, 1)
            .InterfaceType(InterfaceType.USB_TypeC, InterfaceType.Lightning)
            .Build();
            BullSocket bullSocket = new BullSocket("公牛GN-B3440", 8, 1.6f, 10, 2500);
            DelixiSocket delixiSocket = new DelixiSocket("德力西CD98J-LK4X1.8", 4, 1.6f, 10, 2500);
            AndroidCharger miCharger = new AndroidCharger.Builder()
            .BaseInfo("小米MDY-13-ES", "MDY-13-ES", InterfaceType.USB)
            .Current(6.1f, 1.7f)
            .Voltage(220, 11)
            .Build();
            AppleCharger appleCharger = new AppleCharger.Builder()
            .BaseInfo("AppleA2244", "A2244", InterfaceType.USB_TypeC)
            .Current(2.22f, 0.5f)
            .Voltage(240, 9)
            .Build();
            miCharger.ConnectCable(romosChargerCable).ConnectPhone(mi12);
            miCharger.ConnectSocket(delixiSocket).ConnectPower(220);
        }
        /*
        适配器模式在生活中也比较常见，例如我们的手机充电头就是一个适配器，我们无法将家庭电源直接与手机进行连接，
        因为这可能带来较大的安全隐患，并且也不太便利，所以我们需要一个中间的适配器，这个适配器用来保证我们对手机
        进行充电时的安全性和便利性，家用电的输出功率是比较大的，通过电源适配器来控制手机的输入功率，而且还需要考虑
        到电池寿命的问题，长期向手机电池输入大功率可能会导致电池寿命变短，并且220V家用电如果不通过电源适配器来
        保证安全就很有可能导致触电事故，综上采用适配器模式不仅能够帮助我们将手机与家用电源进行间接连接，同时我们
        还能控制家用电源面向手机的输出功率。我们这里的示例简单模拟了手机充电的过程，这个过程中需要手机、充电头、数据线、
        插座，为了更真实地模拟，我们特意加入了输入电流、输出电流、输入电压、输出电压、接口类型等属性，并且对目前市面上
        主流地两种类型手机进行了模拟，一个是安卓手机，另一个是苹果手机，数据线和充电头共同组成电源适配器，我们需要模拟
        家用电源向手机充电的过程。
        */
    }

    //接口类型
    public enum InterfaceType
    {
        USB_TypeC, USB, Micro_USB, Lightning
    }

    //安卓手机
    public class AndroidPhone : Phone
    {
        public AndroidPhone(string p_name, InterfaceType p_phoneInterfaceType, float p_inputCurrent, float p_inputVoltage) :
        base(p_name, p_phoneInterfaceType, p_inputCurrent, p_inputVoltage)
        { }
    }

    //苹果手机
    public class ApplePhone : Phone
    {
        public ApplePhone(string p_name, InterfaceType p_phoneInterfaceType, float p_inputCurrent, float p_inputVoltage) :
        base(p_name, p_phoneInterfaceType, p_inputCurrent, p_inputVoltage)
        { }
    }

    //安卓充电线
    public class AndroidChargerCable : ChargerCable
    {
        public override void ConnectPhone(Phone p_phone)
        {
            if (phoneInterfaceType.Equals(p_phone.phoneInterfaceType))
            {
                if (transmissionCurrent <= p_phone.inputCurrent)
                    Console.WriteLine("【ChargerCable:" + name + "】 successfully connected to 【Phone:" + p_phone.name + "】.");
                else Console.WriteLine("The transmissionCurrent of 【ChargerCable:" + name + "】 greater than inputCurrent of 【Phone:" + p_phone.name + "】.");
            }
            else Console.WriteLine("The phoneInterfaceType of 【ChargerCable:" + name + "】 doesn't match phoneInterfaceType of 【Phone:" + p_phone.name + "】.");
            // p_phone.Print();
        }

        public class Builder
        {
            private AndroidChargerCable acc = new AndroidChargerCable();
            public Builder BaseInfo(string p_name, string p_material, float p_length, float p_transmissionCurrent)
            {
                acc.name = p_name;
                acc.material = p_material;
                acc.length = p_length;
                acc.transmissionCurrent = p_transmissionCurrent;
                return this;
            }
            public Builder InterfaceType(InterfaceType p_chargerInterfaceType, InterfaceType p_phoneInterfaceType)
            {
                acc.chargerInterfaceType = p_chargerInterfaceType;
                acc.phoneInterfaceType = p_phoneInterfaceType;
                return this;
            }
            public AndroidChargerCable Build()
            {
                return acc;
            }
        }
    }

    //苹果充电线
    public class AppleChargerCable : ChargerCable
    {
        public override void ConnectPhone(Phone p_phone)
        {
            if (phoneInterfaceType.Equals(p_phone.phoneInterfaceType))
            {
                if (transmissionCurrent <= p_phone.inputCurrent)
                    Console.WriteLine("【ChargerCable:" + name + "】 successfully connected to 【Phone:" + p_phone.name + "】.");
                else Console.WriteLine("The transmissionCurrent of 【ChargerCable:" + name + "】 greater than inputCurrent of 【Phone:" + p_phone.name + "】.");
            }
            else Console.WriteLine("The phoneInterfaceType of 【ChargerCable:" + name + "】 doesn't match phoneInterfaceType of 【Phone:" + p_phone.name + "】.");
            // p_phone.Print();
        }
        public class Builder
        {
            private AppleChargerCable acc = new AppleChargerCable();
            public Builder BaseInfo(string p_name, string p_material, float p_length, float p_transmissionCurrent)
            {
                acc.name = p_name;
                acc.material = p_material;
                acc.length = p_length;
                acc.transmissionCurrent = p_transmissionCurrent;
                return this;
            }
            public Builder InterfaceType(InterfaceType p_chargerInterfaceType, InterfaceType p_phoneInterfaceType)
            {
                acc.chargerInterfaceType = p_chargerInterfaceType;
                acc.phoneInterfaceType = p_phoneInterfaceType;
                return this;
            }
            public AppleChargerCable Build()
            {
                return acc;
            }
        }
    }

    //公牛插座
    public class BullSocket : Socket
    {
        public BullSocket(string p_name, int p_socketNumber, float p_length, float p_socketCurrent, float p_ratedPower) :
        base(p_name, p_socketNumber, p_length, p_socketCurrent, p_ratedPower)
        { }
        public override void ConnectPower(int p_voltage)
        {
            if (p_voltage < ratedPower / socketCurrent)
                Console.WriteLine("【Socket:" + name + "】 successfully connected to power.");
            else
                Console.WriteLine("The inputMaxVoltage of 【Socket:" + name + "】 less than actualInputVoltage.");
        }
    }

    //德力西插座
    public class DelixiSocket : Socket
    {
        public DelixiSocket(string p_name, int p_socketNumber, float p_length, float p_socketCurrent, float p_ratedPower) :
        base(p_name, p_socketNumber, p_length, p_socketCurrent, p_ratedPower)
        { }
        public override void ConnectPower(int p_voltage)
        {
            if (p_voltage < ratedPower / socketCurrent)
                Console.WriteLine("【Socket:" + name + "】 successfully connected to power.");
            else
                Console.WriteLine("The inputMaxVoltage of 【Socket:" + name + "】 less than actualInputVoltage.");
        }
    }

    //安卓电源适配器
    public class AndroidCharger : Charger
    {
        private AndroidCharger() { }

        public override ChargerCable ConnectCable(ChargerCable p_cable)
        {
            if (chargerInterfaceType.Equals(p_cable.chargerInterfaceType))
            {
                if (outputCurrent <= p_cable.transmissionCurrent)
                    Console.WriteLine("【Charger:" + name + "】 successfully connected to 【ChargerCable:" + p_cable.name + "】.");
                else
                    Console.WriteLine("The outputCurrent of 【Charger:" + name + "】 greater than the transmissionCurrent of 【ChargerCable:" + p_cable.name + "】.");
            }
            else Console.WriteLine("The chargerInterfaceType of 【Charger:" + name + "】 is different from chargerInterfaceType of 【ChargerCable:" + p_cable.name + "】.");
            // p_cable.Print();
            return p_cable;
        }

        public override Socket ConnectSocket(Socket p_socket)
        {
            if (inputCurrent <= p_socket.socketCurrent)
            {
                if (inputCurrent <= p_socket.socketCurrent)
                {
                    if (inputVoltage >= (p_socket.ratedPower - 300f) / 10)
                        Console.WriteLine("【Charger:" + name + "】 successfully connected to 【Socket:" + p_socket.name + "】.");
                    else Console.WriteLine("The inputVoltage of 【Charger:" + name + "】 less than outputVoltage of 【Socket:" + p_socket.name + "】.");
                }
                else Console.WriteLine("The inputCurrent of 【Charger:" + name + "】 greater than socketCurrent of 【Socket:" + p_socket.name + "】.");
            }
            else Console.WriteLine("The inputCurrent of 【Charger:" + name + "】 greater than socketCurrent of 【Socket:" + p_socket.name + "】.");
            // p_socket.Print();
            return p_socket;
        }

        //构建器
        public class Builder
        {
            private AndroidCharger c = new AndroidCharger();
            public Builder BaseInfo(string p_name, string p_model, InterfaceType p_chargerInterfaceType)
            {
                c.name = p_name;
                c.model = p_model;
                c.chargerInterfaceType = p_chargerInterfaceType;
                return this;
            }

            public Builder Current(float p_inputCurrent, float p_outputCurrent)
            {
                c.inputCurrent = p_inputCurrent;
                c.outputCurrent = p_outputCurrent;
                return this;
            }

            public Builder Voltage(float p_inputVoltage, float p_outputVoltage)
            {
                c.inputVoltage = p_inputVoltage;
                c.outputVoltage = p_outputVoltage;
                return this;
            }

            public AndroidCharger Build()
            {
                return c;
            }
        }
    }

    //苹果电源适配器
    public class AppleCharger : Charger
    {
        private AppleCharger() { }

        public override ChargerCable ConnectCable(ChargerCable p_cable)
        {
            if (chargerInterfaceType.Equals(p_cable.chargerInterfaceType))
            {
                if (outputCurrent <= p_cable.transmissionCurrent)
                    Console.WriteLine("【Charger:" + name + "】 successfully connected to 【ChargerCable:" + p_cable.name + "】.");
                else
                    Console.WriteLine("The outputCurrent of 【Charger:" + name + "】 greater than the transmissionCurrent of 【ChargerCable:" + p_cable.name + "】.");
            }
            else Console.WriteLine("The chargerInterfaceType of 【Charger:" + name + "】 is different from chargerInterfaceType of 【ChargerCable:" + p_cable.name + "】.");
            // p_cable.Print();
            return p_cable;
        }

        public override Socket ConnectSocket(Socket p_socket)
        {
            if (inputCurrent <= p_socket.socketCurrent)
            {
                if (inputCurrent <= p_socket.socketCurrent)
                {
                    if (inputVoltage >= (p_socket.ratedPower - 300f) / 10)
                        Console.WriteLine("【Charger:" + name + "】 successfully connected to 【Socket:" + p_socket.name + "】.");
                    else Console.WriteLine("The inputVoltage of 【Charger:" + name + "】 less than outputVoltage of 【Socket:" + p_socket.name + "】.");
                }
                else Console.WriteLine("The inputCurrent of 【Charger:" + name + "】 greater than socketCurrent of 【Socket:" + p_socket.name + "】.");
            }
            else Console.WriteLine("The inputCurrent of 【Charger:" + name + "】 greater than socketCurrent of 【Socket:" + p_socket.name + "】.");
            // p_socket.Print();
            return p_socket;
        }

        //构建器
        public class Builder
        {
            private AppleCharger c = new AppleCharger();
            public Builder BaseInfo(string p_name, string p_model, InterfaceType p_chargerInterfaceType)
            {
                c.name = p_name;
                c.model = p_model;
                c.chargerInterfaceType = p_chargerInterfaceType;
                return this;
            }

            public Builder Current(float p_inputCurrent, float p_outputCurrent)
            {
                c.inputCurrent = p_inputCurrent;
                c.outputCurrent = p_outputCurrent;
                return this;
            }

            public Builder Voltage(float p_inputVoltage, float p_outputVoltage)
            {
                c.inputVoltage = p_inputVoltage;
                c.outputVoltage = p_outputVoltage;
                return this;
            }

            public AppleCharger Build()
            {
                return c;
            }
        }
    }

    //电源适配器基类，所有电源适配器继承该类
    public abstract class Charger
    {
        public string name;
        public string model;
        public InterfaceType chargerInterfaceType;
        public float outputCurrent;
        public float inputCurrent;
        public float outputVoltage;
        public float inputVoltage;
        public void Print()
        {
            Console.WriteLine("【Charger:" + name + "】");
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("[model]:" + model);
            Console.WriteLine("[chargerInterfaceType]:" + chargerInterfaceType);
            Console.WriteLine("[outputCurrent]:" + outputCurrent);
            Console.WriteLine("[inputCurrent]:" + inputCurrent);
            Console.WriteLine("[outputVoltage]:" + outputVoltage);
            Console.WriteLine("[inputVoltage]:" + inputVoltage);
            Console.WriteLine("-----------------------------------");
        }
        public abstract ChargerCable ConnectCable(ChargerCable p_cable);
        public abstract Socket ConnectSocket(Socket p_socket);
    }

    //充电线基类，所有充电线继承该类
    public abstract class ChargerCable
    {
        public string name;
        public InterfaceType chargerInterfaceType;
        public InterfaceType phoneInterfaceType;
        public string material;
        public float length;
        public float transmissionCurrent;
        public void Print()
        {
            Console.WriteLine("【ChargerCable:" + name + "】");
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("[chargerInterfaceType]:" + chargerInterfaceType.ToString());
            Console.WriteLine("[phoneInterfaceType]:" + phoneInterfaceType.ToString());
            Console.WriteLine("[material]:" + material);
            Console.WriteLine("[length]:" + length);
            Console.WriteLine("[transmissionCurrent]:" + transmissionCurrent);
            Console.WriteLine("-----------------------------------");
        }
        public abstract void ConnectPhone(Phone p_phone);
    }

    //手机基类，所有手机继承该类
    public abstract class Phone
    {
        public string name;
        public InterfaceType phoneInterfaceType;
        public float inputCurrent;
        public float inputVoltage;

        public Phone(string p_name, InterfaceType p_phoneInterfaceType, float p_inputCurrent, float p_inputVoltage)
        {
            name = p_name;
            phoneInterfaceType = p_phoneInterfaceType;
            inputCurrent = p_inputCurrent;
            inputVoltage = p_inputVoltage;
        }

        public void Print()
        {
            Console.WriteLine("【Phone:" + name + "】");
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("[phoneInterfaceType]:" + phoneInterfaceType.ToString());
            Console.WriteLine("[inputCurrent]:" + inputCurrent);
            Console.WriteLine("[inputVoltage]:" + inputVoltage);
            Console.WriteLine("-----------------------------------");
        }
    }

    //插座类，所有插座继承该类
    public abstract class Socket
    {
        public string name;
        public int socketNumber;
        public float length;
        public float socketCurrent;
        public float ratedPower;
        public Socket(string p_name, int p_socketNumber, float p_length, float p_socketCurrent, float p_ratedPower)
        {
            name = p_name;
            socketNumber = p_socketNumber;
            length = p_length;
            socketCurrent = p_socketCurrent;
            ratedPower = p_ratedPower;
        }
        public void Print()
        {
            Console.WriteLine("【Socket:" + name + "】");
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("[socketNumber]:" + socketNumber);
            Console.WriteLine("[length]:" + length);
            Console.WriteLine("[socketCurrent]:" + socketCurrent);
            Console.WriteLine("[ratedPower]:" + ratedPower);
            Console.WriteLine("-----------------------------------");
        }
        public abstract void ConnectPower(int p_voltage);
    }
}