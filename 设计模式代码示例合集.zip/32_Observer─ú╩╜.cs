using System;
using System.Collections.Generic;

namespace Test1
{
    class Test32
    {
        public void Test()
        {
            GamePlayer player1 = new GamePlayer("KaKa");
            GamePlayer player2 = new GamePlayer("JoJo");
            EmailSender emailSender = new EmailSender();
            emailSender.Add(player1);
            emailSender.Add(player2);
            emailSender.DoEvent();
            emailSender.DoActions();
        }

        /*
        当一个对象触发某个事件时，其它对象会根据该对象和该事件作出不同响应，这个时候就可以采用观察者模式。
        我们这里是EmailSender作为事件触发对象，触发的事件是发送邮件，当发送邮件后，两个游戏玩家
        作为观察者会显示接收到邮件的提示信息，那么玩家可能会立即阅读邮件，也可能暂不阅读邮件，所以对于玩家来说
        可以作出不同的反应。
        */
    }

    //被观察者：邮件发送者
    class EmailSender : ObservedOject
    {
        public EmailSender()
        {
            observedEvent = new EmailEvent(this);
        }
        public override void Add(Monitor p_monitor)
        {
            monitors.Add(p_monitor);
        }

        public override void DoActions()
        {
            foreach (Monitor m in monitors)
            {
                m.DoAction(observedEvent);
            }
        }

        public override void DoEvent()
        {
            observedEvent.CustomEvent();
        }

        public override void Remove(Monitor p_monitor)
        {
            monitors.Remove(p_monitor);
        }
    }

    //邮件发送者所触发的事件
    class EmailEvent : ObservedEvent
    {
        public EmailEvent(ObservedOject p_source)
        {
            source = p_source;
        }
        public override void CustomEvent()
        {
            Console.WriteLine("EmailEvent is started.");
        }

        public override ObservedOject GetSource()
        {
            return source;
        }
    }

    //观察者：游戏玩家
    class GamePlayer : Monitor
    {
        private string name;
        public GamePlayer(string p_name)
        {
            name = p_name;
        }
        public override void DoAction(ObservedEvent p_event)
        {
            Console.WriteLine(name + " recieve one email.");
        }
    }

    //作为观察者的基类
    public abstract class Monitor
    {
        public abstract void DoAction(ObservedEvent p_event);
    }

    //作为被观察者的基类
    public abstract class ObservedOject
    {
        protected List<Monitor> monitors = new List<Monitor>();
        protected ObservedEvent observedEvent;

        public abstract void Add(Monitor p_monitor);
        public abstract void Remove(Monitor p_monitor);
        public abstract void DoEvent();
        public abstract void DoActions();
    }

    //被观察者所触发事件的基类
    public abstract class ObservedEvent
    {
        protected ObservedOject source;
        public abstract void CustomEvent();
        public abstract ObservedOject GetSource();
    }
}