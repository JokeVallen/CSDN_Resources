using System;
using System.Collections.Generic;

namespace Test1
{
    class Test33
    {
        public void Test()
        {
            BranchNode root = new BranchNode("Root");
            BranchNode node1 = new BranchNode("Node1");
            BranchNode node2 = new BranchNode("Node2");
            BranchNode node3 = new BranchNode("Node3");
            LeafNode node4 = new LeafNode("Node4");
            LeafNode node5 = new LeafNode("Node5");
            LeafNode node6 = new LeafNode("Node6");
            root.Add(node1);
            root.Add(node2);
            node1.Add(node4);
            node2.Add(node3);
            node3.Add(node5);
            node3.Add(node6);

            Draw(root, 1);
        }

        private void Draw(Node p_node, int p_depth)
        {
            string v_str = "";
            for (int i = 0; i < p_depth; i++) v_str += "|";
            Console.WriteLine(v_str + p_node.name);
            if (p_node is BranchNode)
            {
                foreach (Node n in ((BranchNode)p_node).childNodes)
                {
                    Draw(n, p_depth + 1);
                }
            }
        }

        /*
        组合模式多用于树形菜单，文件、文件夹之类的管理，我们这里体现在BranchNode类中的childNodes属性，
        组合模式在于把拥有子节点的BranchNode和没有子节点的LeafNode都看作一个单独的对象，都是Node。LeafNode
        就类似于文件，而BranchNode就类似于文件夹，文件中不能再包含文件或文件夹，但是文件夹下可以包含文件夹和文件。
        */
    }

    //叶子节点，继承Node类
    class LeafNode : Node
    {
        public LeafNode(string p_name) : base(p_name) { }
    }

    //分支节点，继承Node类
    class BranchNode : Node
    {
        public List<Node> childNodes = new List<Node>();

        public BranchNode(string p_name) : base(p_name) { }

        public void Add(Node p_node)
        {
            childNodes.Add(p_node);
        }
        public void Remove(Node p_node)
        {
            childNodes.Remove(p_node);
        }
    }

    //节点抽象类，所有节点继承该类
    public abstract class Node
    {
        public string name;
        public string content;

        public Node(string p_name)
        {
            name = p_name;
        }
    }
}