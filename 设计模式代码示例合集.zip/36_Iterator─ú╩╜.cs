using System;
using System.Text.Json.Serialization;

namespace Test1
{
    class Test36
    {
        public void Test()
        {
            CSFParameter para1 = new CSFParameter("para_1", DataType.Int, 520);
            CSFParameter para2 = new CSFParameter("para_2", DataType.Boolean, true);
            CSFParameter para3 = new CSFParameter("para_3", DataType.Char, 'L');
            CSFParameter para4 = new CSFParameter("para_4", DataType.String, "OVE");
            CSFParameter para5 = new CSFParameter("para_5", DataType.Float, 13.14);
            CSFParameter para6 = new CSFParameter("para_6", DataType.Double, 0.5201314);
            CSFParameter[] parameterArray = { para1, para2, para3, para4, para5, para6 };
            CSFParameters parameters = new CSFParameters(parameterArray);
            CSFParameterList parameterList = new CSFParameterList(2);
            parameterList.Add(para1);
            parameterList.Add(para2);
            parameterList.Add(para3);
            parameterList.Add(para4);
            parameterList.Add(para5);
            parameterList.Add(para6);
            //对CSFParameterList遍历
            while (parameterList.HasNext())
            {
                Console.WriteLine(parameterList.Next());
            }
            //对CSFParameters遍历
            while (parameters.HasNext())
            {
                Console.WriteLine(parameters.Next());
            }
        }

        /*
        迭代器模式主要用于存储结构的遍历，当我们需要对不同类型的存储结构进行遍历时，如果不采用迭代器
        模式就无法对存储结构的程序结构进行限定，这就会导致如果存储结构不提供遍历方法，我们可能就无法对
        其进行遍历，亦或者不同存储结构的遍历方法名称不同，这就使得遍历变得不够便利和简洁，如果我们采用
        迭代器模式，就要求每个存储结构都需要实现迭代器接口，从而我们可以保证每个存储结构都有遍历的方法
        并且遍历方法的名称是相同的，这就提升了存储结构遍历的简易性。结合我们这里的示例，存储结构主要是
        CSFParameters和CSFParameterList，它们都实现了迭代器接口ICSFIterator中的HasNext方法和Next方法，
        当然如果存在其它存储结构也需要实现迭代器接口中的方法，这样我们在对它们进行遍历时就很容易了。
        */
    }

    /// <summary>
    /// Array是非标准类型数组(也就是自定义的其它数据类型，例如Student[]，这个Student是自定义的类并不是标准类型)，StringArray是string数组，IntArray是Int32数组
    /// </summary>
    public enum DataType
    {
        None, Char, String, Int16, Int, Int64,
        DateTime, Float, Double, Array, StringArray, IntArray,
        Boolean
    }

    //一种自定义的数据结构，CSFParameters
    public class CSFParameters : CSFParametersStruct, ICSFIterator<CSFParameter>
    {
        /// <summary>
        /// CSFParameters构造方法
        /// <para>p_capacity：初始容量大小，默认为10</para>
        /// </summary>
        public CSFParameters(int p_capacity = 10)
        {
            capacity = p_capacity;
            parameters = new CSFParameter[capacity];
            index = 0;
            count = 0;
        }

        /// <summary>
        /// CSFParameters构造方法
        /// <para>p_parameters：CSFParamter数组</para>
        /// </summary>
        public CSFParameters(CSFParameter[] p_parameters)
        {
            int len = p_parameters.Length;
            parameters = new CSFParameter[len];
            p_parameters.CopyTo(parameters, 0);
            capacity = len;
            count = capacity;
            index = 0;
        }

        public bool HasNext()
        {
            if (index < count) return true;
            return false;
        }

        public CSFParameter Next()
        {
            if (count > 0)
            {
                return parameters[index++];
            }
            return null;
        }

        //添加参数元素
        public override void Add(string p_parameterName, DataType p_type, object p_value)
        {
            if (count < capacity && RepeatValueCheck(p_parameterName))
            {
                if (count < capacity)
                {
                    parameters[count].parameterName = p_parameterName;
                    parameters[count].type = p_type;
                    parameters[count].value = p_value;
                }
                count++;
            }
        }

        //添加参数元素
        public override void Add(CSFParameter p_parameter)
        {
            if (count < capacity && RepeatValueCheck(p_parameter.parameterName))
            {
                parameters[count] = p_parameter;
                count++;
            }
        }

        //删除参数元素
        public override void Remove(CSFParameter p_parameter)
        {
            for (int i = 0; i < count; i++)
            {
                if (parameters[i].parameterName.Equals(p_parameter.parameterName))
                {
                    parameters[i].parameterName = "";
                    parameters[i].type = DataType.None;
                    parameters[i].value = null;
                    MoveForward(i);
                    count--;
                    break;
                }
            }
        }

        //设置参数元素
        public override void SetValue(string p_parameterName, DataType p_type)
        {
            int i = IndexOf(p_parameterName);
            if (i != -1)
            {
                parameters[i].type = p_type;
            }
        }

        //设置参数元素
        public override void SetValue(string p_parameterName, object p_value)
        {
            int i = IndexOf(p_parameterName);
            if (i != -1)
            {
                parameters[i].value = p_value;
            }
        }

        //设置参数元素
        public override void SetValue(string p_parameterName, DataType p_type, object p_value)
        {
            int i = IndexOf(p_parameterName);
            if (i != -1)
            {
                parameters[i].type = p_type;
                parameters[i].value = p_value;
            }
        }

        public override string ToString()
        {
            string v_str = "";
            v_str += '\n' + new String('-', 42) + '\n';
            for (int i = 0; i < count; i++)
            {
                if (!parameters[i].type.ToString().Equals("Array"))
                {
                    v_str += parameters[i].parameterName + " " + parameters[i].type.ToString() + " " + parameters[i].value.ToString() + "\n";
                }
                else
                {
                    v_str += parameters[i].parameterName + " " + parameters[i].type.ToString() + "[";
                    var array = (CSFParameter[])parameters[i].value;
                    for (int j = 0; j < array.Length; j++)
                    {
                        if (j < array.Length - 1) v_str += array[j] + ",";
                        else v_str += array[j] + "]\n";
                    }
                }
            }
            v_str += new String('-', 42) + '\n';
            return v_str;
        }

        //索引器，下标为参数名称，返回一个CSFParameter
        public CSFParameter this[string p_parameterName]
        {
            get
            {
                return Find(p_parameterName);
            }
            private set { }
        }

        //根据参数名称查找参数元素索引
        private int IndexOf(string p_parameterName)
        {
            for (int i = 0; i < count; i++)
            {
                if (parameters[i].parameterName.Equals(p_parameterName)) return i;
            }
            return -1;
        }

        //根据参数名称查找参数元素
        private CSFParameter Find(string p_parameterName)
        {
            for (int i = 0; i < count; i++)
            {
                if (parameters[i].parameterName.Equals(p_parameterName))
                {
                    return parameters[i];
                }
            }
            return null;
        }

        //将索引为p_i+1的参数元素向前移动一个单位
        private void MoveForward(int p_i)
        {
            for (int i = p_i + 1; i < count; i++)
            {
                parameters[i - 1] = parameters[i];
            }
        }

        //重复参数元素检测，无重复值返回true，否则返回false
        private bool RepeatValueCheck(string p_parameterName)
        {
            for (int i = 0; i < count; i++)
            {
                if (parameters[i].parameterName.Equals(p_parameterName)) return false;
            }
            return true;
        }

        //清空参数元素
        public override void Clear()
        {
            if (count > 0)
            {
                for (int i = 0; i < count; i++)
                {
                    parameters[i].parameterName = "";
                    parameters[i].type = DataType.None;
                    parameters[i].value = null;
                }
                count = 0;
            }
        }
    }

    //一种自定义的数据结构，CSFParameter
    [Serializable]
    public class CSFParameter
    {
        [JsonInclude]
        public string parameterName;
        [JsonInclude]
        public DataType type;
        [JsonInclude]
        public object value;

        /// <summary>
        /// CSFParameter构造方法
        /// <para>p_parameterName：参数名称</para>
        /// <para>p_type：参数类型</para>
        /// <para>p_value：参数值</para>
        /// </summary>
        public CSFParameter(string parameterName, DataType type, object value)
        {
            this.parameterName = parameterName;
            this.type = type;
            this.value = value;
        }

        public override string ToString()
        {
            if (value == null) return parameterName + " " + type.ToString() + " null";
            else return parameterName + " " + type.ToString() + " " + value.ToString();
        }
    }

    //一种自定义的数据结构，CSFParameterList
    public class CSFParameterList : CSFParameterListStruct, ICSFIterator<CSFParameter>
    {
        public CSFParameterList(int p_capacity = 10)
        {
            capacity = p_capacity;
            count = 0;
            index = 0;
            parameters = new CSFParameter[capacity];
        }

        public override void Add(CSFParameter p_parameter)
        {
            ExtendCapacityCheck();
            if (RepeatValueCheck(p_parameter.parameterName))
            {
                parameters[count] = p_parameter;
                count++;
            }
        }

        public override void Clear()
        {
            if (count > 0)
            {
                for (int i = 0; i < count; i++)
                {
                    parameters[i].parameterName = "";
                    parameters[i].type = DataType.None;
                    parameters[i].value = null;
                }
                count = 0;
            }
        }

        public override bool Contains(CSFParameter p_parameter)
        {
            if (IndexOf(p_parameter) == -1) return false;
            return true;
        }

        public bool HasNext()
        {
            if (index < count) return true;
            return false;
        }

        public CSFParameter Next()
        {
            if (count > 0)
            {
                return parameters[index++];
            }
            return null;
        }

        public override void Remove(CSFParameter p_parameter)
        {
            for (int i = 0; i < count; i++)
            {
                if (parameters[i].parameterName.Equals(p_parameter.parameterName))
                {
                    parameters[i].parameterName = "";
                    parameters[i].type = DataType.None;
                    parameters[i].value = null;
                    MoveForward(i);
                    count--;
                    break;
                }
            }
        }

        public override void SetValue(CSFParameter p_parameter)
        {
            int i = IndexOf(p_parameter);
            if (i != -1)
            {
                parameters[i] = p_parameter;
            }
        }

        public override int IndexOf(CSFParameter p_parameter)
        {
            for (int i = 0; i < count; i++)
            {
                if (parameters[i].parameterName.Equals(p_parameter.parameterName)) return i;
            }
            return -1;
        }

        //重复参数元素检测，无重复值返回true，否则返回false
        private bool RepeatValueCheck(string p_parameterName)
        {
            for (int i = 0; i < count; i++)
            {
                if (parameters[i].parameterName.Equals(p_parameterName)) return false;
            }
            return true;
        }

        //将索引为p_i+1的参数元素向前移动一个单位
        private void MoveForward(int p_i)
        {
            for (int i = p_i + 1; i < count; i++)
            {
                parameters[i - 1] = parameters[i];
            }
        }

        private void ExtendCapacityCheck()
        {
            if (count >= capacity) capacity *= 2;
            CSFParameter[] v_parameters = new CSFParameter[capacity];
            parameters.CopyTo(v_parameters, 0);
            parameters = v_parameters;
        }
    }

    //用于进行类型转换的工具类
    public class CSFConvert
    {
        public static Int16 ToInt16(object p_data)
        {
            return System.Convert.ToInt16(p_data);
        }

        public static int ToInt(object p_data)
        {
            return System.Convert.ToInt32(p_data);
        }

        public static Int64 ToInt64(object p_data)
        {
            return System.Convert.ToInt64(p_data);
        }

        public static Char ToChar(object p_data)
        {
            return System.Convert.ToChar(p_data);
        }

        public static string ToString(object p_data)
        {
            return System.Convert.ToString(p_data);
        }

        public static DateTime ToDateTime(object p_data)
        {
            return System.Convert.ToDateTime(p_data);
        }

        public static float ToFloat(object p_data)
        {
            return System.Convert.ToSingle(p_data);
        }

        public static double ToDouble(object p_data)
        {
            return System.Convert.ToDouble(p_data);
        }
    }

    //CSFParameterList的基类
    public abstract class CSFParameterListStruct
    {
        protected CSFParameter[] parameters;
        protected int capacity;
        protected int count;
        protected int index;

        /// <summary>
        /// 添加参数元素
        /// <para>p_parameter：参数元素</para>
        /// </summary>
        public abstract void Add(CSFParameter p_parameter);

        /// <summary>
        /// 删除参数元素
        /// <para>p_parameterName：参数名称</para>
        /// </summary>
        public abstract void Remove(CSFParameter p_parameter);

        /// <summary>
        /// 清空参数元素
        /// </summary>
        public abstract void Clear();

        /// <summary>
        /// 是否包含指定参数元素
        /// <para>p_paramater：待检测的参数元素</para>
        /// <para>返回值：包含指定参数元素则返回true，否则返回false</para>
        /// </summary>
        public abstract bool Contains(CSFParameter p_parameter);

        /// <summary>
        /// 设置参数元素
        /// <para>p_parameter：修改后的参数元素</para>
        /// </summary>
        public abstract void SetValue(CSFParameter p_parameter);

        /// <summary>
        /// 查找对应参数元素对应的索引
        /// <para>p_parameter：待查找参数元素</para>
        /// <para>返回值：待查找参数元素对应的索引</para>
        /// </summary>
        public abstract int IndexOf(CSFParameter p_parameter);

        /// <summary>
        /// 获取当前参数元素个数
        /// 返回值：当前参数元素个数
        /// </summary>
        public int Count()
        {
            return count;
        }
    }

    //CSFParameters的基类
    public abstract class CSFParametersStruct
    {
        //参数名称数组
        protected CSFParameter[] parameters;
        //当前参数元素个数
        protected int count;
        //容量
        protected int capacity;
        //索引
        protected int index;

        /// <summary>
        /// 添加参数元素
        /// <para>p_parameterName：参数名称</para>
        /// <para>p_type：参数类型</para>
        /// <para>p_value：参数值</para>
        /// </summary>
        public abstract void Add(string p_parameterName, DataType p_type, object p_value);

        /// <summary>
        /// 添加参数元素
        /// <para>p_parameter：参数元素</para>
        /// </summary>
        public abstract void Add(CSFParameter p_parameter);

        /// <summary>
        /// 删除参数元素
        /// <para>p_parameterName：参数名称</para>
        /// </summary>
        public abstract void Remove(CSFParameter p_parameter);

        /// <summary>
        /// 清空参数元素
        /// </summary>
        public abstract void Clear();

        /// <summary>
        /// 设置参数元素
        /// <para>p_parameterName：参数名称</para>
        /// <para>p_type：参数类型</para>
        /// </summary>
        public abstract void SetValue(string p_parameterName, DataType p_type);

        /// <summary>
        /// 设置参数元素
        /// <para>p_parameterName：参数名称</para>
        /// <para>p_value：参数值</para>
        /// </summary>
        public abstract void SetValue(string p_parameterName, object p_value);

        /// <summary>
        /// 设置参数元素
        /// <para>p_parameterName：参数名称</para>
        /// <para>p_type：参数类型</para>
        /// <para>p_value：参数值</para>
        /// </summary>
        public abstract void SetValue(string p_parameterName, DataType p_type, object p_value);

        /// <summary>
        /// 获取当前参数元素个数
        /// 返回值：当前参数元素个数
        /// </summary>
        public int Count()
        {
            return count;
        }
    }

    //具备迭代器功能的接口
    public interface ICSFIterator<T>
    {
        public bool HasNext();
        public T Next();
    }
}