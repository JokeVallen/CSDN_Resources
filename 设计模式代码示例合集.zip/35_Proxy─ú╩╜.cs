using System.Threading;
using System;

namespace Test1
{
    class Test35
    {
        delegate void f();
        event f f1;
        public void Test()
        {
            Man m1 = new Man("小王");
            Man m2 = new Man("小张");
            Man m3 = new Man("小林");
            Man m4 = new Man("小方");
            Man m5 = new Man("小陈");
            //可以在new对象时，传递下一个待执行的代理，以此实现代理嵌套
            TimerProxy timerProxy = new TimerProxy();
            PrintProxy printProxy = new PrintProxy();
            PermissionProxy permissionProxy = new PermissionProxy(true);
            //如果不采用new对象时传递参数的方式来实现代理嵌套，也可以通过Next方法传递下一个待执行的代理
            permissionProxy.Next(printProxy);
            printProxy.Next(timerProxy);
            f1 += m1.Walk;
            // timerProxy.Invoke(f1);
            // printProxy.Invoke(f1);
            permissionProxy.Invoke(f1);
        }
        /*
        代理模式顾名思义就是对一些业务逻辑进行代理，例如我们这里的对方法执行的打印，方法执行耗时的统计，
        方法执行权限的检测，这些代理之所以独立出来作为代理就是因为它们有两个特点，第一是复用性高，第二是
        它们通常需要在某个方法执行前后实现一些独有的业务逻辑，我们秉承对扩展开放对修改关闭的原则，所以采
        用了代理模式，如果不采用这种设计模式，我们要实现方法执行前后添加业务逻辑的目的就需要修改源码，这
        明显是不太好的，我们把方法的执行交给代理，这样就可以通过代理实现我们的目的了，并且我们还可以更方便
        地实现多重代理嵌套，这里虽然没有完全实现动态代理，但是也存在一定动态的实现，第一待执行的方法由调用者
        传入，我们这里是通过委托实现的，调用者负责传入对应的委托和方法参数，为了安全性考虑，我们采用事件，
        这么做的好处就是方法是否有参数，是否有返回值，参数是什么就完全由调用者指定了，这样就比较动态地实现了
        代理的功能，不足的地方就是调用者需要先定义事件或委托，然后自行对事件和委托进行方法添加，这使得使用
        代理显得较为繁琐。
        */
    }

    public class Man
    {
        public string name;
        public Man(string p_name)
        {
            name = p_name;
        }
        public void Walk()
        {
            Console.WriteLine("The man named " + name + " is walking.");
            Thread.Sleep(new Random().Next(3000));
        }
    }

    //打印方法的代理
    class PrintProxy : Proxy, IProxy
    {
        public PrintProxy(IProxy p_proxy = null) : base(p_proxy) { }
        public object Invoke(Delegate p_delegate, params object[] p_params)
        {
            object o = null;
            Before();
            if (proxy != null)
            {
                proxy.Invoke(p_delegate, p_params);
            }
            else o = p_delegate.DynamicInvoke(p_params);
            After();
            return o;
        }

        private void Before()
        {
            Console.WriteLine("Function starts.");
        }

        private void After()
        {
            Console.WriteLine("Function stop.");
        }

        public override void Next(IProxy p_proxy)
        {
            proxy = p_proxy;
        }
    }

    //时间统计的代理
    class TimerProxy : Proxy, IProxy
    {
        private DateTime beginTime;
        private DateTime endTime;
        public TimerProxy(IProxy p_proxy = null) : base(p_proxy) { }
        public object Invoke(Delegate p_delegate, params object[] p_params)
        {
            object o = null;
            Before();
            if (proxy != null)
            {
                proxy.Invoke(p_delegate, p_params);
            }
            else o = p_delegate.DynamicInvoke(p_params);
            After();
            return o;
        }

        private void Before()
        {
            beginTime = DateTime.Now;
        }

        private void After()
        {
            endTime = DateTime.Now;
            Console.WriteLine("TimeSpan:" + endTime.Subtract(beginTime).TotalMilliseconds);
        }

        public override void Next(IProxy p_proxy)
        {
            proxy = p_proxy;
        }
    }

    //权限控制的代理
    class PermissionProxy : Proxy, IProxy
    {
        private bool isPermission;
        public PermissionProxy(bool p_isPermission, IProxy p_proxy = null) : base(p_proxy) { isPermission = p_isPermission; }
        public object Invoke(Delegate p_delegate, params object[] p_params)
        {
            object o = null;
            if (isPermission)
            {
                Console.WriteLine("The function meets the permission.");
                if (proxy != null) o = proxy.Invoke(p_delegate, p_params);
                else o = p_delegate.DynamicInvoke(p_params);
            }
            else Console.WriteLine("The function doesn't meet the permission.");
            return o;
        }

        public override void Next(IProxy p_proxy)
        {
            proxy = p_proxy;
        }
    }

    //代理基类，所有代理继承该类
    public abstract class Proxy
    {
        protected IProxy proxy;
        public Proxy(IProxy p_proxy = null)
        {
            proxy = p_proxy;
        }
        public abstract void Next(IProxy p_proxy);
    }

    //所有代理均需要实现该接口
    public interface IProxy
    {
        public object Invoke(Delegate p_delegate, params object[] p_params);
    }
}