using System;

namespace Test1
{
    class Test45
    {
        public void Test()
        {
            IEnemyStatus normal = new Normal();
            IEnemyStatus manic = new Manic();
            OneEnemy enemy = new OneEnemy();
            enemy.Attck(normal);
            enemy.Skill(normal);
            enemy.Attck(manic);
            enemy.Skill(manic);
        }
        /*
        State模式多适用于一组行为在不同状态下的不同实现。示例中我们的敌人暂定为只有攻击和技能
        两个行为受状态影响，分为Normal和Manic两个状态，OneEnemy代表敌人类，敌人有攻击和技能
        两个行为，但是我们要求传递敌人状态，这样我们就能够实现不同状态下敌人的行为实现，并且
        能够轻易对状态进行扩展，但是不足的是对行为的扩展是繁琐的，所以State模式适用于行为固定
        但是状态不固定的情况。
        */
    }

    public class OneEnemy
    {
        public void Attck(IEnemyStatus p_status)
        {
            p_status.Attack();
        }
        public void Skill(IEnemyStatus p_status)
        {
            p_status.Skill();
        }
    }

    public class Normal : IEnemyStatus
    {
        public void Attack()
        {
            Console.WriteLine("The enemy seems normal,and his attack seems weak.");
        }

        public void Skill()
        {
            Console.WriteLine("The normal enemy does his best to perform his normal skill.");
        }
    }

    public class Manic : IEnemyStatus
    {
        public void Attack()
        {
            Console.WriteLine("The enemy seems so angry,and his attack seems very powerful.");
        }

        public void Skill()
        {
            Console.WriteLine("The manic enemy does his best to perform his lethal skill.");
        }
    }

    public interface IEnemyStatus
    {
        public void Attack();
        public void Skill();
    }
}