using System.Reflection;
using System;
using System.Collections.Generic;

namespace Test1
{
    class Test25
    {
        public void Test()
        {
            //1-1未使用抽象类
            //每一个交通工具需要自己手动创建出来
            Car c = new Car();
            c.Start();
            MagicBroom ap = new MagicBroom();
            ap.Start();

            //1-2使用抽象类
            //Car和MagicBroom都是交通工具
            Vehicle vehicle = new Car();
            vehicle.Start();
            vehicle = new MagicBroom();
            vehicle.Start();

            //1-3使用简单工厂来创建产品
            VehicleFactory factory = VehicleFactory.GetInstance();
            factory.CreateCar();
            factory.CreateMagicBroom();

            //1-4使用静态工厂来创建产品
            WeaponFactory.CreateGun();
            WeaponFactory.CreateMagicBroom();
            Type[] types = { typeof(MagicPower), typeof(Bread), typeof(MagicPower), typeof(Bread) };
            foreach (Type item in types)
            {
                var food = FoodFactory.CreateFood(item);
                if (food != null) food.Eat();
                else Console.WriteLine("Failure to create food.");
            }

            //1-5使用抽象工厂来创建产品族
            AbstractFactory absfactory = ModernFactory.GetInstance();
            List<Vehicle> vehicles = new List<Vehicle>();
            List<Weapon> weapons = new List<Weapon>();
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    vehicles.Add(absfactory.CreateVehicle());
                    weapons.Add(absfactory.CreateWeapon());
                }
                for (int k = 0; k < vehicles.Count; k++)
                {
                    vehicles[k].Start();
                    weapons[k].Attack();
                    vehicles[k].Stop();
                }
                vehicles.Clear();
            }
        }
    }

    //食物静态工厂
    //这个工厂不同于下面武器静态工厂的地方是这里面只有一个CreateFood方法
    //调用者的产品只要满足以下两个条件即可通过该工厂生产食物:
    //1.要求食物都继承自Food
    //2.无参构造方法公开(如果没有单独声明构造方法，默认为公开的无参构造)
    //这种方法存在两个问题，第一它是通过反射来调用构造方法，所以速度非常慢，第二由于存在对公共资源的读取，所以多线程访问需要锁
    //第一个问题如果想要改进，可以创建一个静态数据结构用于存储已经调用过至少一次的对应类型的构造方法信息，这样，当下次再调用时就不需要再去查找构造信息了，可以直接从存储中调用，这种方法也算是牺牲存储来换取速度吧，类似于一种缓存
    //第二个问题我们需要访问的公共资源就是为了解决第一个问题的静态数据结构，当多个线程中都调用工厂生产食品时，就会存在资源冲突，所以必须对资源加锁访问，但是这又会导致我们生产食品时一个一个生产，而不能够多线程生产，这就违背工厂的本质了
    public class FoodFactory
    {
        private static List<ConstructorInfo> cis = new List<ConstructorInfo>();
        private static List<Type> types = new List<Type>();
        private FoodFactory() { }

        public static Food CreateFood(Type p_type)
        {
            if (types.Count != cis.Count) return null;
            if (!types.Contains(p_type))
            {
                ConstructorInfo ci = p_type.GetConstructor(new Type[0]);
                if (ci == null) return null;
                else if (!cis.Contains(ci))
                {
                    cis.Add(ci);
                    types.Add(p_type);
                    return (Food)ci.Invoke(null);
                }
                else return null;
            }
            else
            {
                int index = types.IndexOf(p_type);
                return (Food)cis[index].Invoke(null);
            }
        }

        //用于清除缓存的食物构造方法信息和食物类型
        public static void Clear()
        {
            cis.Clear();
            types.Clear();
        }
    }

    //武器静态简单工厂
    public class WeaponFactory
    {
        private WeaponFactory() { }

        public static Weapon CreateGun()
        {
            return new Gun();
        }

        public static Weapon CreateMagicBroom()
        {
            return new MagicWand();
        }
    }

    //交通工具简单工厂
    public class VehicleFactory
    {
        private VehicleFactory() { }
        private class VehicleFactoryHandler
        {
            public static readonly VehicleFactory instance = new VehicleFactory();
        }

        public static VehicleFactory GetInstance()
        {
            return VehicleFactoryHandler.instance;
        }

        public Car CreateCar()
        {
            return new Car();
        }

        public MagicBroom CreateMagicBroom()
        {
            return new MagicBroom();
        }
    }

    //抽象工厂————现代工厂，现代工厂用于生产现代世界的物品，继承AbstractFactory
    public class ModernFactory : AbstractFactory
    {
        private ModernFactory() { }
        private class ModernFactoryHandler
        {
            public static readonly ModernFactory instance = new ModernFactory();
        }

        public static ModernFactory GetInstance()
        {
            return ModernFactoryHandler.instance;
        }

        public override Vehicle CreateVehicle()
        {
            Console.WriteLine("Create one car.");
            return new Car();
        }

        public override Weapon CreateWeapon()
        {
            Console.WriteLine("Create one gun.");
            return new Gun();
        }
    }

    //抽象工厂————魔法工厂，魔法工厂用于生产魔法世界的物品，继承AbstractFactory
    public class MagicFactory : AbstractFactory
    {
        private MagicFactory() { }
        private class MagicFactoryHandler
        {
            public static readonly MagicFactory instance = new MagicFactory();
        }

        public static MagicFactory GetInstance()
        {
            return MagicFactoryHandler.instance;
        }

        public override Vehicle CreateVehicle()
        {
            Console.WriteLine("Create one magicbroom.");
            return new MagicBroom();
        }

        public override Weapon CreateWeapon()
        {
            Console.WriteLine("Create one magicwand.");
            return new MagicWand();
        }
    }

    //具体交通工具————汽车，继承Vehicle
    public class Car : Vehicle
    {
        public override void Start()
        {
            Console.WriteLine("The car started.");
        }

        public override void Stop()
        {
            Console.WriteLine("The car braked.");
        }
    }

    //具体武器————枪，继承Weapon
    public class Gun : Weapon
    {
        public override void Attack()
        {
            Console.WriteLine("I shoot you with a gun.");
        }
    }

    //具体食物————面包，继承Food
    public class Bread : Food
    {
        public Bread() { }
        public override void Eat()
        {
            Console.WriteLine("The bread tastes delicious.");
        }
    }

    //具体交通工具————魔法扫帚，继承Vehicle
    public class MagicBroom : Vehicle
    {
        public override void Start()
        {
            Console.WriteLine("The magicbroom flight.");
        }

        public override void Stop()
        {
            Console.WriteLine("The magicbroom landed.");
        }
    }

    //具体武器————魔法棒，继承Weapon
    public class MagicWand : Weapon
    {
        public override void Attack()
        {
            Console.WriteLine("I attacked you with a magicwand.");
        }
    }

    //具体食物————魔法能量，继承Food
    public class MagicPower : Food
    {
        public override void Eat()
        {
            Console.WriteLine("The power makes me powerful.");
        }
    }

    //抽象工厂类，定义所有工厂都需要具备的产品线
    public abstract class AbstractFactory
    {
        public abstract Vehicle CreateVehicle();
        public abstract Weapon CreateWeapon();
    }

    //抽象类Vehicle，定义所有交通工具都具备的功能
    public abstract class Vehicle
    {
        public abstract void Start();
        public abstract void Stop();
    }

    //抽象类Weapon，定义所有武器都具备的功能
    public abstract class Weapon
    {
        public abstract void Attack();
    }

    //抽象类Food，定义所有食物都具备的功能
    public abstract class Food
    {
        public abstract void Eat();
    }
}