using System.IO;
using System.Text.Json;

namespace Test1
{
    /*
    Memento模式用于记录存档点，然后可以通过加载存档点回溯到指定的存档或状态。结合Command模式，
    我们对一个文本编辑器进行了简单的模拟，我们可以添加、删除、复制文本，同时还可以存储和加载命
    令状态。这个命令状态存储比较特殊，存储数据会覆盖当前的命令及其状态，这说明我们既保存了文本
    也保存了对文本的操作命令，当我们重新加载后文本和当时相关的操作命令都会一起恢复。
    */
    //文本和文本操作命令的存储与加载功能的具体实现类
    public class CommandChainManager : IMemento
    {
        private const string v_textPath = @"D:\Study\StudyNotes\Gamemade notes\ProgramPractice\Test1\源文件\Datas\data.txt";
        private const string v_paramsPath = @"D:\Study\StudyNotes\Gamemade notes\ProgramPractice\Test1\源文件\Datas\params.json";
        public void LoadCommand(ref CommandChain p_commandChain)
        {
            string v_jsonStr = "";
            using (StreamReader sr = File.OpenText(v_paramsPath))
            {
                v_jsonStr = sr.ReadToEnd();
            }
            var options = new JsonSerializerOptions
            {
                IncludeFields = true
            };
            CSFParameter[][] parameters = JsonSerializer.Deserialize<CSFParameter[][]>(v_jsonStr, options);
            p_commandChain.parameters.Clear();
            foreach (CSFParameter[] param in parameters)
            {
                p_commandChain.parameters.Add(param);
            }
        }

        public void LoadText(ref string p_text)
        {
            using (StreamReader sr = File.OpenText(v_textPath))
            {
                p_text = sr.ReadToEnd();
            }
        }

        public void SaveCommands(CommandChain p_commandChain)
        {
            var options = new JsonSerializerOptions
            {
                IncludeFields = true
            };
            string v_jsonStr = JsonSerializer.Serialize<CSFParameter[][]>(p_commandChain.parameters.ToArray(), options);
            File.WriteAllText(v_paramsPath, v_jsonStr);
        }

        public void SaveText(string p_text)
        {
            File.WriteAllText(v_textPath, p_text);
        }
    }

    //实现文本和文本操作命令存储与加载的接口
    public interface IMemento
    {
        public void SaveText(string p_text);
        public void LoadText(ref string p_text);
        public void SaveCommands(CommandChain p_commandChain);
        public void LoadCommand(ref CommandChain p_commandChain);
    }
}