using System;

namespace Test1
{
    class Test40
    {
        public void Test()
        {
            Man jojo = new Man("JoJo");
            Man kaka = new Man("KaKa");

            RedDyer redDyer = new RedDyer(Color.Red);
            OrangeDyer orangeDyer = new OrangeDyer(Color.Orange);
            PurpleDyer purpleDyer = new PurpleDyer(Color.Purple);
            WhiteDyer whiteDyer = new WhiteDyer(Color.White);

            Shirt shirt = new Shirt("Shirt", "cotton", Season.Spring, whiteDyer);
            Sweater sweater = new Sweater("Sweater", "polyester-fiber", Season.Autumn, orangeDyer);
            ShortSleeve shortSleeve = new ShortSleeve("ShortSleeve", "cotton", Season.Summer, purpleDyer);
            Jacket jacket = new Jacket("Jacket", "polyester-fiber and cotton", Season.Winter, redDyer);

            shirt.Dressed(jojo);
            jacket.Dressed(jojo);
            shortSleeve.Dressed(kaka);
            sweater.Dressed(kaka);
        }
        /*
        我们简单模拟了一下衣服的染色过程，我们有Shirt、Sweater、ShortSleeve、Jacket四种类型的衣服，
        并且每种衣服都可以染Red、Orange、Purple、White四种不同的颜色，这样就会有16种组合，如果每种
        组合我们都去定义一个类就会出现类爆炸问题，所以我们就可以采用桥接模式，将衣服与染色先分开，二者
        分别创建一个基类Clothes和ColorDyer，四种衣服分别继承Clothes基类，四种染色器分别继承ColorDyer，
        但是我们在Clothes基类中定义一个ColorDyer，这里就实现了Clothes与ColorDyer的桥接模式，当我们制作
        一件衣服时需要通过一个染色器进行染色，当我们下次有一种新的衣服或新的染色器时只需要添加一个类即可，
        就不需要再定义四个类，这就是桥接模式的好处。
        */
    }

    //季节
    public enum Season
    {
        Spring, Summer, Autumn, Winter
    }

    //颜色
    public enum Color
    {
        Red, Blue, Orange, White, Black, Yellow, Green, Purple
    }

    public class Shirt : Clothes
    {
        public Shirt(string p_name, string p_material, Season p_applicableSeason, ColorDyer p_colorDyer) :
        base(p_name, p_material, p_applicableSeason, p_colorDyer)
        { }
        public override void Dressed(Man p_man)
        {
            Console.WriteLine("------------------------------------");
            colorDyer.Dye();
            Console.WriteLine(p_man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
        }
    }

    public class Sweater : Clothes
    {
        public Sweater(string p_name, string p_material, Season p_applicableSeason, ColorDyer p_colorDyer) :
        base(p_name, p_material, p_applicableSeason, p_colorDyer)
        { }
        public override void Dressed(Man p_man)
        {
            Console.WriteLine("------------------------------------");
            colorDyer.Dye();
            Console.WriteLine(p_man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
        }
    }

    public class ShortSleeve : Clothes
    {
        public ShortSleeve(string p_name, string p_material, Season p_applicableSeason, ColorDyer p_colorDyer) :
        base(p_name, p_material, p_applicableSeason, p_colorDyer)
        { }
        public override void Dressed(Man p_man)
        {
            Console.WriteLine("------------------------------------");
            colorDyer.Dye();
            Console.WriteLine(p_man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
        }
    }

    public class Jacket : Clothes
    {
        public Jacket(string p_name, string p_material, Season p_applicableSeason, ColorDyer p_colorDyer) :
        base(p_name, p_material, p_applicableSeason, p_colorDyer)
        { }
        public override void Dressed(Man p_man)
        {
            Console.WriteLine("------------------------------------");
            colorDyer.Dye();
            Console.WriteLine(p_man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
        }
    }

    public class RedDyer : ColorDyer
    {
        public RedDyer(Color p_color) : base(p_color) { }

        public override void Dye()
        {
            Console.WriteLine("The dress is dyed red.");
        }
    }

    public class OrangeDyer : ColorDyer
    {
        public OrangeDyer(Color p_color) : base(p_color) { }

        public override void Dye()
        {
            Console.WriteLine("The dress is dyed orange.");
        }
    }

    public class PurpleDyer : ColorDyer
    {
        public PurpleDyer(Color p_color) : base(p_color) { }

        public override void Dye()
        {
            Console.WriteLine("The dress is dyed purple.");
        }
    }

    public class WhiteDyer : ColorDyer
    {
        public WhiteDyer(Color p_color) : base(p_color) { }

        public override void Dye()
        {
            Console.WriteLine("The dress is dyed white.");
        }
    }

    public abstract class Clothes
    {
        public string name;
        public string material;
        public Season applicableSeason;
        protected ColorDyer colorDyer;
        public Clothes(string p_name, string p_material, Season p_applicableSeason, ColorDyer p_colorDyer)
        {
            name = p_name;
            material = p_material;
            applicableSeason = p_applicableSeason;
            colorDyer = p_colorDyer;
        }
        public abstract void Dressed(Man p_man);
    }

    public abstract class ColorDyer
    {
        public Color color;
        public ColorDyer(Color p_color) { color = p_color; }
        public abstract void Dye();
    }
}