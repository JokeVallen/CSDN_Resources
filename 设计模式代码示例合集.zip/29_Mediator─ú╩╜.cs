using System.Threading;
using System.Collections.Generic;
using System;

namespace Test1
{
    class Test29
    {
        public void Test()
        {
            Mediator mediator = new Mediator();
            SeniorManagement seniorManagement = new SeniorManagement("王高管", mediator);
            SimpleEmployee simpleEmployee1 = new SimpleEmployee("小李", mediator);
            SimpleEmployee simpleEmployee2 = new SimpleEmployee("小张", mediator);
            SimpleEmployee simpleEmployee3 = new SimpleEmployee("小吴", mediator);

            seniorManagement.DispatchTask();
            simpleEmployee1.ReceviceTask();
            simpleEmployee2.ReceviceTask();
            simpleEmployee3.ReceviceTask();
            simpleEmployee1.SubmitReport();
            simpleEmployee2.SubmitReport();
            simpleEmployee3.SubmitReport();
            seniorManagement.ReceviceReport();
        }

        /*
        调停者模式体现在系统内各模块之间显式调用的解耦，我们这里就是将Mediator这个类作为调停者，
        我们把SimpleEmployee与SeniorManagement中的Send和Recevice方法的调用交给Mediator代理，
        这就避免了二者之间的显示调用，降低模块间的耦合性。
        */
    }

    //调停者类
    class Mediator : AbstractMediator
    {
        private SeniorManagement senior = null;
        private List<SimpleEmployee> employees = new List<SimpleEmployee>();

        public override void Register(AbstrctStaff p_staff)
        {
            if (p_staff is SeniorManagement) senior = (SeniorManagement)p_staff;
            else employees.Add((SimpleEmployee)p_staff);
        }

        public override void Recevice(AbstrctStaff p_staff)
        {
            if (p_staff is SimpleEmployee)
            {
                p_staff.Recevice(senior.name);
            }
            else
            {
                foreach (SimpleEmployee e in employees)
                {
                    p_staff.Recevice(e.name);
                }
            }
        }

        public override void Send(AbstrctStaff p_staff)
        {
            p_staff.Send();
        }
    }

    //公司普通员工类
    class SimpleEmployee : AbstractEmployee
    {
        public SimpleEmployee(string p_name, AbstractMediator p_mediator) : base(p_mediator)
        {
            name = p_name;
            mediator.Register(this);
        }
    }

    //公司高管类
    class SeniorManagement : AbstractManagement
    {
        public SeniorManagement(string p_name, AbstractMediator p_mediator) : base(p_mediator)
        {
            name = p_name;
            mediator.Register(this);
        }
    }

    //调停者抽象类
    public abstract class AbstractMediator
    {
        public abstract void Register(AbstrctStaff p_staff);
        public abstract void Recevice(AbstrctStaff p_staff);
        public abstract void Send(AbstrctStaff p_staff);
    }

    //公司普通员工抽象类
    public abstract class AbstractEmployee : AbstrctStaff
    {
        public AbstractEmployee(AbstractMediator p_mediator)
        {
            mediator = p_mediator;
        }

        public override void Recevice(string p_seniorManagementName)
        {
            Console.WriteLine("普通员工" + name + "接收到了" + p_seniorManagementName + "布置的任务！");
        }

        public void ReceviceTask()
        {
            mediator.Recevice(this);
        }

        public override void Send()
        {
            Console.WriteLine(name + "提交了报告！");
        }

        public void SubmitReport()
        {
            mediator.Send(this);
        }
    }

    //公司高管抽象类
    public abstract class AbstractManagement : AbstrctStaff
    {
        public AbstractManagement(AbstractMediator p_mediator)
        {
            mediator = p_mediator;
        }

        public override void Recevice(string p_employeeName)
        {
            Console.WriteLine(name + "接收了普通员工" + p_employeeName + "的任务报告！");
        }

        public void ReceviceReport()
        {
            mediator.Recevice(this);
        }

        public override void Send()
        {
            Console.WriteLine(name + "发布了任务！");
        }

        public void DispatchTask()
        {
            mediator.Send(this);
        }
    }

    //公司员工抽象类，作为公司高管和普通员工的基类
    public abstract class AbstrctStaff
    {
        protected AbstractMediator mediator;
        public string name;

        public abstract void Send();
        public abstract void Recevice(string p_interactor);
    }
}