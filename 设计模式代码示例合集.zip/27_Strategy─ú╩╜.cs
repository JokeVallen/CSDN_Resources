using System;

namespace Test1
{
    class Test27
    {
        Mouse[] mouses = { new Mouse(3, 3), new Mouse(5, 5), new Mouse(1, 1) };
        Dog[] dogs = { new Dog(3, 3), new Dog(5, 5), new Dog(1, 1) };
        public void Test()
        {
            Sorter.Sort(mouses, new WeightComparator());
            Sorter.Sort(dogs, new HeightComparator());
            for (int i = 0; i < mouses.Length; i++)
            {
                Console.WriteLine(mouses[i]);
            }
            for (int i = 0; i < mouses.Length; i++)
            {
                Console.WriteLine(dogs[i]);
            }
        }
        /*
        策略模式就体现在本实例的比较器这里，当我们需要扩展不同的比较方式时只需要实现
        IComparator<T>接口即可，之所以让所有比较对象继承AbstractAnimal这个抽象类，
        是因为每当我们添加一个动物时，都需要在Sorter中去重载不同的Sort方法，如果采
        用抽象类，我们则不需要进行这个操作，当我们需要扩展不同的动物时只需要继承AbstractAnimal就可以了
        这么做是为了遵循设计模式中的开闭原则，之所以让AbstractAnimal实现IComparable<T>接口，
        是为了让所有动物都具备一个基本的CompareTo方法，这么做可以让我们在对于使用者不传递比较器的
        情况下，使用CompareTo作为默认比较方式，所以可以对Sort方法进行一个重载————public static void Sort(AbstractAnimal[] p_animals)
        */
    }

    //排序调用类，需要排序则可以通过该类直接调用静态方法
    class Sorter
    {
        //排序方法
        public static void Sort(AbstractAnimal[] p_animals, IComparator<AbstractAnimal> p_sorter)
        {
            for (int i = 0; i < p_animals.Length; i++)
            {
                for (int j = i + 1; j < p_animals.Length; j++)
                {
                    if (p_sorter.Compare(p_animals[i], p_animals[j]) == 1)
                    {
                        AbstractAnimal temp = p_animals[i];
                        p_animals[i] = p_animals[j];
                        p_animals[j] = temp;
                    }
                }
            }
        }
    }

    //米老鼠
    class Mouse : AbstractAnimal
    {
        public Mouse(int p_weight, int p_height)
        {
            this.weight = p_weight;
            this.height = p_height;
        }

        public override int CompareTo(AbstractAnimal p_t)
        {
            if (this.weight > p_t.weight) return 1;
            else if (this.weight < p_t.weight) return -1;
            return 0;
        }

        public override string ToString()
        {
            return "Mouse{weight:" + this.weight + ",height:" + this.height + "}";
        }
    }

    //修勾
    class Dog : AbstractAnimal
    {
        public Dog(int p_weight, int p_height)
        {
            this.weight = p_weight;
            this.height = p_height;
        }

        public override int CompareTo(AbstractAnimal p_t)
        {
            if (this.weight > p_t.weight) return 1;
            else if (this.weight < p_t.weight) return -1;
            return 0;
        }
        public override string ToString()
        {
            return "Dog{weight:" + this.weight + ",height:" + this.height + "}";
        }
    }

    //体重比较器
    class WeightComparator : IComparator<AbstractAnimal>
    {
        public int Compare(AbstractAnimal p_t1, AbstractAnimal p_t2)
        {
            if (p_t1.weight > p_t2.weight) return 1;
            else if (p_t1.weight < p_t2.weight) return -1;
            return 0;
        }
    }

    //身高比较器
    class HeightComparator : IComparator<AbstractAnimal>
    {
        public int Compare(AbstractAnimal p_t1, AbstractAnimal p_t2)
        {
            if (p_t1.height < p_t2.height) return 1;
            else if (p_t1.height > p_t2.height) return -1;
            return 0;
        }
    }

    //比较器接口，所有比较器需要实现这个接口
    public interface IComparator<T>
    {
        public int Compare(T p_t1, T p_t2);
    }

    //可比较接口，待比较对象需要实现这个接口
    public interface IComparable<T>
    {
        public int CompareTo(T p_t);
    }

    //动物抽象类，所有动物需要继承该类
    public abstract class AbstractAnimal : IComparable<AbstractAnimal>
    {
        public int weight;
        public int height;
        public abstract int CompareTo(AbstractAnimal p_t);
    }
}