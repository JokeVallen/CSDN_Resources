using System;

namespace Test2
{
    class Test30
    {
        public void Test()
        {
            Gun gun = new Gun("JoJo");
            Sword sword = new Sword("KaKa");
            Decorator flameDecorator = new FlameDecorator();
            Decorator redDecorator = new RedDecorator();

            flameDecorator.SetWeapon(gun);
            redDecorator.SetWeapon(gun);
            flameDecorator.Decoration();

            flameDecorator.SetWeapon(sword);
            redDecorator.SetWeapon(sword);
            flameDecorator.Decoration();
            redDecorator.Decoration();
        }
        /*
        装饰器模式是在于对一个现有的对象添加新的功能，同时又不改变其结构。我们这里的装饰器有两个，
        一个是FlameDecorator，另一个是RedDecorator，它们都继承了Decorator，它们可以给武器添加
        属性、技能、颜色，我们不需要去修改武器结构，只需要将武器对象传递给装饰器即可。
        */
    }

    //枪
    class Gun : Weapon
    {
        public Gun(string p_name)
        {
            name = p_name;
        }
        public override void Attack()
        {
            Console.WriteLine("Use the gun named " + name + " to attack the enemy.");
        }
    }

    //剑
    class Sword : Weapon
    {
        public Sword(string p_name)
        {
            name = p_name;
        }
        public override void Attack()
        {
            Console.WriteLine("Use the sword named " + name + " to attack the enemy.");
        }
    }

    //火焰属性装饰器，用于添加火焰属性
    class FlameDecorator : Decorator
    {
        private void AddFlameAttribute()
        {
            Console.WriteLine("Add flame attribute to the weapon " + weapon.name);
        }

        private void AddFlameSkill()
        {
            Console.WriteLine("Add flame skill to the weapon " + weapon.name);
        }

        public override void Decoration()
        {
            if (weapon != null)
            {
                weapon.Decoration();
                AddFlameAttribute();
                AddFlameSkill();
            }
        }
    }

    //红色装饰器，用于添加红色
    class RedDecorator : Decorator
    {
        private void SetRedColor()
        {
            Console.WriteLine("Add red color to the weapon " + weapon.name);
        }

        public override void Decoration()
        {
            if (weapon != null)
            {
                weapon.Decoration();
                SetRedColor();
            }
        }
    }

    //武器抽象类，作为所有武器的基类
    public abstract class Weapon : IDecorate
    {
        public string name;

        public abstract void Attack();

        public void Decoration()
        {
            Console.WriteLine("【Weapon " + name + "】");
        }
    }

    //装饰功能接口，需要拥有装饰功能则实现该接口
    public interface IDecorate
    {
        public void Decoration();
    }

    //装饰器抽象类，作为所有装饰器的基类
    public abstract class Decorator : IDecorate
    {
        protected Weapon weapon;

        public virtual void Decoration()
        {
            weapon.Decoration();
        }

        public void SetWeapon(Weapon p_weapon)
        {
            weapon = p_weapon;
        }
    }
}