using System;

namespace Test1
{
    class Test38
    {
        public void Test()
        {
            CinemachineParameters cp = new CinemachineParameters.Builder()
            .SetLookahead(1.1f, 2.1f, false)
            .SetScreen(1920, 1080)
            .SetDamping(1.3f, 1.4f, 5.20f)
            .Build();
            CinemachineParameters cp2 = new CinemachineParameters.Builder()
            .SetLookahead(1.3f, 1.4f, false)
            .SetScreen(1314, 520)
            .SetDamping(1.3f, 1.4f, 5.20f)
            .Build();
            Console.WriteLine(cp.ScreenX + " " + cp.ScreenY);
            Console.WriteLine(cp2.ScreenX + " " + cp2.ScreenY);
        }
        /*
        当我们需要new一个对象，但是它需要的参数比较多，并且我们并不是所有参数都需要传递时，就可以
        使用构建器模式，通过这个模式，我们可以将待传入的参数进行分组，并且能够动态传递需要的参数，
        不过缺点就是对于参数的分组会固定，面对不同的需求就有不同的分组标准，相对于传统的构造函数，
        这种构建器的方式有诸多优点，第一解决了参数无法可选传入的问题，第二解决了书写繁琐可读性低的问题。
        */
    }

    public class CinemachineParameters
    {
        public float TrackedObjectOffset;
        public float LookaheadTime;
        public float LookaheadSmoothing;
        public bool LookaheadIgnoreY;
        public float XDamping;
        public float YDamping;
        public float ZDamping;
        public bool TargetMovementOnly;
        public int ScreenX;
        public int ScreenY;
        public float CameraDistance;
        public float DeadZoneWidth;
        public float DeadZoneHeight;
        public float DeadZoneDepth;
        public bool UnlimitedSoftZone;
        public float SoftZoneWidth;
        public float SoftZoneHeight;
        public float BiasX;
        public float BiasY;
        public bool CenterOnActive;
        private CinemachineParameters() { }

        public class Builder
        {
            private CinemachineParameters cp = new CinemachineParameters();
            public Builder SetLookahead(float p_lookaheadTime, float p_lookaheadSmoothing, bool p_lookaheadIgnoreY)
            {
                cp.LookaheadTime = p_lookaheadTime;
                cp.LookaheadSmoothing = p_lookaheadSmoothing;
                cp.LookaheadIgnoreY = p_lookaheadIgnoreY;
                return this;
            }

            public Builder SetDamping(float p_xDamping, float p_yDamping, float p_zDamping)
            {
                cp.XDamping = p_xDamping;
                cp.YDamping = p_yDamping;
                cp.ZDamping = p_zDamping;
                return this;
            }

            public Builder SetScreen(int p_screenX, int p_screenY)
            {
                cp.ScreenX = p_screenX;
                cp.ScreenY = p_screenY;
                return this;
            }

            public Builder SetDeadZone(float p_deadZoneWidth, float p_deadZoneHeight, float p_deadZoneDepth)
            {
                cp.DeadZoneWidth = p_deadZoneWidth;
                cp.DeadZoneHeight = p_deadZoneHeight;
                cp.DeadZoneDepth = p_deadZoneDepth;
                return this;
            }

            public Builder SetSoftZone(bool p_unlimitedSoftZone, float p_softZoneWidth, float p_softZoneHeight)
            {
                cp.UnlimitedSoftZone = p_unlimitedSoftZone;
                cp.SoftZoneWidth = p_softZoneWidth;
                cp.SoftZoneHeight = p_softZoneHeight;
                return this;
            }

            public Builder SetBias(float p_biasX, float p_biasY)
            {
                cp.BiasX = p_biasX;
                cp.BiasY = p_biasY;
                return this;
            }

            public Builder SetOther(float p_trackedObjectOffset, bool p_targetMovementOnly, float p_cameraDistance, bool p_centerOnActive)
            {
                cp.TrackedObjectOffset = p_trackedObjectOffset;
                cp.TargetMovementOnly = p_targetMovementOnly;
                cp.CameraDistance = p_cameraDistance;
                cp.CenterOnActive = p_centerOnActive;
                return this;
            }

            public CinemachineParameters Build()
            {
                return cp;
            }
        }
    }
}