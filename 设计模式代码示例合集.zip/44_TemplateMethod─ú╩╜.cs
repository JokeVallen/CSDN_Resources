using System;

namespace Test1
{
    class Test44
    {
        public void Test()
        {
            Father carefulFather = new CarefulFather();
            Father carelessFather = new CarelessFather();
            Baby baby = new Baby(BabyStatus.Hungry);
            carefulFather.TakeCare(baby);
            carelessFather.TakeCare(baby);
        }
        /*
        基于这个示例，有一个Father基类，两个派生类CarefulFather和CarelessFather继承该基类，二者分别对
        Option1方法和Option2方法进行了重写，但是两个Option方法没有进行显示调用，因为两个方法的调用已经
        交给了Father基类负责，只需要调用TakeCare方法就会自动调用两个Option方法。一个基类提供可重写的方
        法给派生类而可重写方法的调用由基类负责，这种模式就叫TemplateMethod模式。
        */
    }

    public enum BabyStatus
    {
        Sleepy, Hungry
    }

    public class Baby
    {
        public BabyStatus status { get; private set; }
        public Baby(BabyStatus p_status) { status = p_status; }
        public void Cry()
        {
            Console.WriteLine("The baby is crying,she feels " + status.ToString().ToLower() + ".");
        }
    }

    public class CarefulFather : Father
    {
        protected override void Option1(BabyStatus p_status)
        {
            if (p_status.Equals(BabyStatus.Hungry))
            {
                Console.WriteLine("Acording to the crying of baby,the careful father knows that the baby is hungry.");
                Console.WriteLine("Therefore,the father feeds the baby milk powder.");
            }
        }

        protected override void Option2(BabyStatus p_status)
        {
            if (p_status.Equals(BabyStatus.Sleepy))
            {
                Console.WriteLine("Acording to the crying of baby,the careful father knows that the baby is sleepy.");
                Console.WriteLine("Therefore,the father taps the baby to sleep.");
            }
        }
    }

    public class CarelessFather : Father
    {
        protected override void Option1(BabyStatus p_status)
        {
            if (p_status.Equals(BabyStatus.Sleepy))
            {
                Console.WriteLine("Acording to the crying of baby,the careless father mistakes the baby for hungry.");
                Console.WriteLine("Therefore,the father feeds the baby milk powder.");
            }
        }

        protected override void Option2(BabyStatus p_status)
        {
            if (p_status.Equals(BabyStatus.Hungry))
            {
                Console.WriteLine("Acording to the crying of baby,the careless father mistakes the baby for sleep.");
                Console.WriteLine("Therefore,the father taps the baby to sleep.");
            }
        }
    }

    public abstract class Father
    {
        public void TakeCare(Baby p_baby)
        {
            p_baby.Cry();
            Option1(p_baby.status);
            Option2(p_baby.status);
        }

        protected virtual void Option1(BabyStatus p_status) { }
        protected virtual void Option2(BabyStatus p_status) { }
    }
}