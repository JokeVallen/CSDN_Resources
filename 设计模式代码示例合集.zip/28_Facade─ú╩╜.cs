using System;

namespace Test1
{
    class Test28
    {
        public void Test()
        {
            Facade facade = new Facade();
            facade.Shopping();
            facade.Cancle();
        }

        /*
        门面模式主要体现在我们使用的Facade这个类，我们将客户端对服务端的调用交给Facade，
        客户端只需要通过Facade调用方法，而不需要去关注流程中具体的业务逻辑或更多子流程，
        例如购买商品，如果采用之前的方式，客户端就需要分别调用OrderSystem的SubmitOrder()、
        GoodsSystem的SendGood()、MoneySystem的Pay()，如果是采用门面模式，只需要调用Facade的Shopping()
        当然我们这里只有三个系统，如果我们的业务流程复杂，涉及几十个系统甚至更多，如果不采用门面模式就会
        面临两个问题：首先是我们需要让客户端与几十个系统建立连接，其次是每次创建一个新的客户端就需要单独
        与几十个系统建立连接。这两个问题明显不是我们想要看到的，我们希望能够对客户端与各个系统的连接进行
        封装，客户端只需要调用一个指定的方法完成指定的功能即可，即一种面向服务的架构（SOA），这里的Facade就
        类似于消息中间件，只不过我们不是使用的队列。
        */
    }

    //门面
    public class Facade
    {
        private static OrderSystem orderSys = new OrderSystem();
        private static GoodsSystem goodsSys = new GoodsSystem();
        private static MoneySystem moneySys = new MoneySystem();
        public void Shopping()
        {
            moneySys.Pay();
            orderSys.SubmitOrder();
            goodsSys.SendGood();
        }

        public void Cancle()
        {
            orderSys.CancleOrder();
            goodsSys.StopSend();
            moneySys.ReturnMoney();
        }
    }

    //订单系统
    class OrderSystem
    {
        public void SubmitOrder()
        {
            Console.WriteLine("提交订单");
        }

        public void CancleOrder()
        {
            Console.WriteLine("取消订单");
        }
    }

    //商品系统
    class GoodsSystem
    {
        public void SendGood()
        {
            Console.WriteLine("发送货物");
        }

        public void StopSend()
        {
            Console.WriteLine("停止发送货物");
        }
    }

    //支付系统
    class MoneySystem
    {
        public void Pay()
        {
            Console.WriteLine("付款");
        }

        public void ReturnMoney()
        {
            Console.WriteLine("退款");
        }
    }
}