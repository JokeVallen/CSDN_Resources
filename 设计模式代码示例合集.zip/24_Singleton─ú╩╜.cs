using System.Threading;

namespace Test1
{
    class Test24
    {
        public void Test()
        {
            for (int i = 0; i < 30; i++)
            {
                Thread.Sleep(10);
                new Thread(() =>
                {
                    SingleTon1 singleTon1 = SingleTon1.GetInstance();
                    Console.WriteLine("singleTon1:" + singleTon1.GetHashCode());
                }).Start();
                new Thread(() =>
                {
                    SingleTon2 singleTon2 = SingleTon2.GetInstance();
                    Console.WriteLine("singleTon2:" + singleTon2.GetHashCode());
                }).Start();
            }
        }
    }

    class SingleTon1
    {
        private static SingleTon1 instance;
        private static readonly object k = new object();

        private SingleTon1() { }

        public static SingleTon1 GetInstance()
        {
            if (instance == null)
            {
                lock (k)
                {
                    if (instance == null) instance = new SingleTon1();
                }
            }
            return instance;
        }
    }

    class SingleTon2
    {
        private SingleTon2() { }

        private class SingleTon2Handler
        {
            public static readonly SingleTon2 instance = new SingleTon2();
        }

        public static SingleTon2 GetInstance()
        {
            return SingleTon2Handler.instance;
        }
    }
}