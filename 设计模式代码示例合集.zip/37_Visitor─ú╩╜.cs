using System;

namespace Test1
{
    class Test37
    {
        public void Test()
        {
            Kitchen kitchen = new Kitchen("kitchen");
            Toilet toilet = new Toilet("toilet");
            Bedroom bedroom = new Bedroom("bedroom");
            Apartment apartment = new Apartment("apartment", kitchen, toilet, bedroom);
            Villa villa = new Villa("villa", kitchen, toilet, bedroom);
            Child child = new Child();
            Woman woman = new Woman();
            apartment.Accept(child).VisitEnd();
            apartment.Accept(woman).VisitEnd();
            villa.Accept(child).VisitEnd();
            villa.Accept(woman).VisitEnd();
        }
        /*
        当一个类的结构不再发生改变，但是我们需要从类的外部动态实现或改变该类里面的一些方法时，我们就需要
        用到访客模式。我们这里的示例就是不同访客来游览不同的房屋，每个房屋都需要继承House基类，其中
        WelcomeAndInstructions方法用于介绍这是什么类型的房屋以及房屋中的各个房间用来做什么，accept方法
        用于接待访客，房屋的结构一旦确定就不会再进行改变了，但是如果我们不采用访客模式，那么接待不同的访客
        我们都需要通过修改或添加房屋中的接待方法，这就违背了开闭原则，如果我们把这个接待方法改为访问方法，
        我们规定每个访客都需要一个Visit方法，以及与房屋结构相适应的VisitKitchen、VisitToilet、VisitBedroom
        等方法，作为房屋就只需要直接调用参观的访客的Visit方法即可，毕竟访客要怎么参观是访客要做的事情，我们交给
        访客自己去定义就行了，房屋只需要知道访客是否要参观即可，有一个问题就是，为什么我这里需要添加一个Visit方法，
        原则上只需要VisitKitchen、VisitToilet、VisitBedroom这三个方法就能够达到我们的目的了，这是因为我考虑到
        访客他自己的参观顺序，这个参观顺序也是访客自己决定的，作为房屋是不能够去限定访客的参观顺序的，所以添加了Visit方法。
        */
    }

    //公寓，房屋类型之一
    public class Apartment : House
    {
        public Apartment(string p_name, HousePart p_kitchen, HousePart p_toilet, HousePart p_bedroom) :
        base(p_name, p_kitchen, p_toilet, p_bedroom)
        { }

        public override IVisitor Accept(IVisitor p_visitor)
        {
            WelcomeAndInstructions();
            p_visitor.Visit();
            return p_visitor;
        }

        protected override void WelcomeAndInstructions()
        {
            Console.WriteLine("Welcome to my " + name + ".");
            kitchen.Do();
            bedroom.Do();
            toilet.Do();
        }
    }

    //别墅，房屋类型之一
    public class Villa : House
    {
        public Villa(string p_name, HousePart p_kitchen, HousePart p_toilet, HousePart p_bedroom) :
        base(p_name, p_kitchen, p_toilet, p_bedroom)
        { }

        public override IVisitor Accept(IVisitor p_visitor)
        {
            WelcomeAndInstructions();
            p_visitor.Visit();
            return p_visitor;
        }

        protected override void WelcomeAndInstructions()
        {
            Console.WriteLine("Welcome to my " + name + ".");
            kitchen.Do();
            bedroom.Do();
            toilet.Do();
        }
    }

    //厨房，房屋结构之一
    public class Kitchen : HousePart
    {
        public Kitchen(string p_name) : base(p_name) { }
        public override void Do()
        {
            Console.WriteLine("Welcome to " + name + ".This is a place for cooking.");
        }
    }

    //厕所，房屋结构之一
    public class Toilet : HousePart
    {
        public Toilet(string p_name) : base(p_name) { }
        public override void Do()
        {
            Console.WriteLine("Welcome to " + name + ".This is a place to return to nature.");
        }
    }

    //卧室，房屋结构之一
    public class Bedroom : HousePart
    {
        public Bedroom(string p_name) : base(p_name) { }
        public override void Do()
        {
            Console.WriteLine("Welcome to " + name + ".This is a place to sleep.");
        }
    }

    //儿童，访客类型之一
    public class Child : IVisitor
    {
        public void Visit()
        {
            VisitBedroom();
            VisitKitchen();
            VisitToilet();
        }

        public void VisitBedroom()
        {
            Console.WriteLine("The child plays in the bedroom");
        }

        public void VisitEnd()
        {
            Console.WriteLine("-----------------------------------");
        }

        public void VisitKitchen()
        {
            Console.WriteLine("The child feels hungry,so he wants to find some foods to eat in the kitchen.");
        }

        public void VisitToilet()
        {
            Console.WriteLine("Beacuse of drinking much juice,the child wants to return to nature.");
        }

    }

    //女士，访客类型之一
    public class Woman : IVisitor
    {
        public void Visit()
        {
            VisitToilet();
            VisitBedroom();
            VisitKitchen();
        }

        public void VisitEnd()
        {
            Console.WriteLine("-----------------------------------");
        }

        public void VisitBedroom()
        {
            Console.WriteLine("The woman feels sleepy so that she is fast asleep in the bedroom.");
        }

        public void VisitKitchen()
        {
            Console.WriteLine("The woman feels a little hungry after a sleep and she find some cookies in the refrigerator of kitchen luckily.");
        }

        public void VisitToilet()
        {
            Console.WriteLine("The woman wants to return to nature beacuse of drinking much wine last night.");
        }
    }

    //访客接口，所有访客实现该接口
    public interface IVisitor
    {
        public void VisitKitchen();
        public void VisitToilet();
        public void VisitBedroom();
        public void Visit();
        public void VisitEnd();
    }

    //房屋基类，所有房屋继承该基类
    public abstract class House
    {
        protected string name;
        protected HousePart kitchen;
        protected HousePart toilet;
        protected HousePart bedroom;
        public House(string p_name, HousePart p_kitchen, HousePart p_toilet, HousePart p_bedroom)
        {
            name = p_name;
            kitchen = p_kitchen;
            toilet = p_toilet;
            bedroom = p_bedroom;
        }
        protected abstract void WelcomeAndInstructions();
        public abstract IVisitor Accept(IVisitor p_visitor);
    }

    //房屋结构基类，所有房屋结构继承该基类
    public abstract class HousePart
    {
        public string name;
        public HousePart(string p_name) { name = p_name; }
        public abstract void Do();
    }
}