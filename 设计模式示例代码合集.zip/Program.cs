﻿// ************* 1.单例模式测试 **************
// using SingleTonPattern;

// SingleTonPatternManager singleTonPatternManager = new SingleTonPatternManager();
// singleTonPatternManager.Test();

// ************* 2.简单工厂模式测试 **************
// using FactoryPattern;

// var accessoryFactory = new SimpleFactory.AccessoryFactory();
// PhoneMotherBoard phoneMotherBoard = accessoryFactory.CreatePMB(); // 手机主板
// PhoneScreen phoneScreen = accessoryFactory.CreatePS(); // 手机屏幕
// ComputerMotherBoard computerMotherBoard = accessoryFactory.CreateCMB(); // 电脑主板
// ComputerScreen computerScreen = accessoryFactory.CreateCS(); // 电脑屏幕
// phoneMotherBoard.OperationPA();
// phoneScreen.OperationPA();
// computerMotherBoard.OperationCA();
// computerScreen.OperationCA();

// ************* 3.工厂方法模式测试 **************
// using FactoryPattern;

// IFactoryMethod phoneMotherBoardFactory = new FactoryMethodPattern.PhoneMotherBoardFactory();
// IFactoryMethod phoneScreenFactory = new FactoryMethodPattern.PhoneScreenFactory();
// IPhoneAccessory phoneMotherBoard = phoneMotherBoardFactory.Create(); // 手机主板
// IPhoneAccessory phoneScreen = phoneScreenFactory.Create(); // 手机屏幕
// phoneMotherBoard.OperationPA();
// phoneScreen.OperationPA();

// ************* 4.抽象工厂模式测试 **************
// using FactoryPattern;

// IFactory computerFactory = new AbstractFactoryPattern.MotherBoardFactory();
// IFactory phoneFactory = new AbstractFactoryPattern.ScreenFactory();
// IMotherBoard computerMB = computerFactory.CreateMB(); // 电脑主板
// IScreen computerSC = computerFactory.CreateSC(); // 电脑屏幕
// IMotherBoard phoneMB = phoneFactory.CreateMB(); // 手机主板
// IScreen phoneSC = phoneFactory.CreateSC(); // 手机屏幕
// computerMB.OperationMB();
// computerSC.OperationSC();
// phoneMB.OperationMB();
// phoneSC.OperationSC();

// ************* 5.策略模式测试 **************
// using StrategyPattern;

// Animal[] cats =
// {
//     new Cat("橘猫",20f,0.78f),
//     new Cat("狸花猫",15f,0.72f),
//     new Cat("英国短尾猫",18f,0.65f),
// };

// WeightStrategy weightStrategy = new WeightStrategy();
// LengthStrategy lengthStrategy = new LengthStrategy();

// Console.WriteLine("*************** 按照体重从小到大对所有猫进行排序并输出 *****************");
// StrategyPatternManager strategyPattern = new StrategyPatternManager(weightStrategy);
// strategyPattern.Sort(cats);
// for (int i = 0; i < cats.Length; i++)
// {
//     Console.WriteLine(cats[i]);
// }

// Console.WriteLine("*************** 按照长度从大到小对所有猫进行排序并输出 *****************");
// strategyPattern = new StrategyPatternManager(lengthStrategy);
// strategyPattern.Sort(cats, false);
// for (int i = 0; i < cats.Length; i++)
// {
//     Console.WriteLine(cats[i]);
// }

// ************* 6.门面模式（外观模式）测试 **************
// using FacadePattern;

// FacadePatternManager facadePattern = new FacadePatternManager();
// facadePattern.Shopping();
// Console.WriteLine("---------------------------------------------");
// facadePattern.Cancle();

// ************* 7.中介者模式（调停者模式）测试 **************
// using MediatorPattern;

// Chatroom chatroom = new Chatroom();

// Colleague wxm = new Colleague("王小明", chatroom);
// Colleague en = new Colleague("二妮", chatroom);
// Colleague kk = new Colleague("康康", chatroom);

// Console.WriteLine("聊天室禁言功能已关闭...");
// wxm.SendMessage("管理员总算解除全体禁言了！");
// en.SendMessage("可不是嘛，都两周没聊天了。T^T");
// kk.SendMessage("无所谓，不禁言我就来，禁言我也还有其它事情可以做。");

// ************* 8.装饰器模式测试 **************
// using DecoratorPattern;

// IWeapon sword = new Sword();
// IWeapon gun = new Gun();

// Console.WriteLine("不添加装饰器...");
// sword.Operation();
// gun.Operation();

// Console.WriteLine("添加装饰器...");
// IWeapon fireSword = new FireDecorator(sword);
// fireSword.Operation();
// IWeapon redGun = new RedDecorator(gun);
// redGun.Operation();

// ************* 9.责任链模式测试 **************
// using CORPattern;
// # nullable disable

// // 定义三种快捷键指令的处理，指令处理的传递顺序：cut => copy => paste
// ShortcutHandler paste = new Paste(null);
// ShortcutHandler copy = new Copy(paste);
// ShortcutHandler cut = new Cut(copy);

// // 开始测试Ctrl+V指令
// cut.Handle(Shortcut.CTRL_V);
// cut.Handle(Shortcut.CTRL_X);
// cut.Handle(Shortcut.CTRL_C);
// cut.Handle(Shortcut.None);

// ************* 10.观察者模式测试 **************
// using ObserverPattern;

// Toggle toggle = new Toggle();
// WindowA windowA = new WindowA();
// WindowB windowB = new WindowB();

// // 向Toggle组件注册两个窗口为观察者
// toggle.Register(windowA);
// toggle.Register(windowB);

// // 设置Toggle组件的状态为Disabled
// toggle.state = UIItemState.Disabled;

// // 设置Toggle组件的状态为Enabled
// toggle.state = UIItemState.Enabled;

// ************* 11.组合模式测试 **************
// // 创建三个文件和两个文件夹
// CompositePattern.File fileA = new CompositePattern.File("文件A");
// CompositePattern.File fileB = new CompositePattern.File("文件B");
// CompositePattern.File fileC = new CompositePattern.File("文件C");
// CompositePattern.Directory directoryA = new CompositePattern.Directory("文件夹A");
// CompositePattern.Directory directoryB = new CompositePattern.Directory("文件夹B");

// // 文件夹B中包含文件A和文件C
// directoryB.Add(fileA);
// directoryB.Add(fileC);

// // 文件夹A中包含文件B和文件夹B
// directoryA.Add(fileB);
// directoryA.Add(directoryB);

// // 显示文件夹A及其目录下的所有子文件夹和子文件
// directoryA.Show(1);

// ************* 12.享元模式测试 **************
// using FlyweightPattern;
// #pragma warning disable

// // 创建图形管理器实例并获取圆形和矩形
// ShapeManager shapeManager = new ShapeManager();
// Circle circle = shapeManager.GetShape(ShapeType.Circle) as Circle;
// Rectangle rectangle = shapeManager.GetShape(ShapeType.Rectangle) as Rectangle;

// // 绘制红色的圆形和蓝色的矩形
// circle.Draw("red");
// rectangle.Draw("blue");

// // 再次获取一个圆形并绘制成蓝色的圆形
// Circle otherCircle = shapeManager.GetShape(ShapeType.Circle) as Circle;
// otherCircle.Draw("blue");

// ************* 13.代理模式测试 **************
// using ProxyPattern;

// DebugProxy debug = new DebugProxy();
// debug.Log("This is a paragraph.");

// ************* 14.迭代器模式测试 **************
// using IteratorPattern;

// // 定义集合元素合集并传递给集合实例，通过集合实例获取迭代器
// CollectionItem[] collectionItems = { new CollectionItem(1), new CollectionItem(2), new CollectionItem(3) };
// Collection collection = new Collection(collectionItems);
// IIterator iterator = collection.GetIterator();

// // 通过迭代器遍历集合
// while (iterator.HasNext())
// {
//     Console.WriteLine(iterator.next);
// }

// ************* 15.访问者模式测试 **************
// using VisitorPattern;

// Kitchen kitchen = new Kitchen("kitchen");
// Toilet toilet = new Toilet("toilet");
// Bedroom bedroom = new Bedroom("bedroom");
// Apartment apartment = new Apartment("apartment", kitchen, toilet, bedroom);
// Villa villa = new Villa("villa", kitchen, toilet, bedroom);

// Child child = new Child("Bob");
// Woman woman = new Woman("Amy");

// // 孩子和女士访问公寓
// apartment.Accept(child).VisitEnd();
// apartment.Accept(woman).VisitEnd();

// // 孩子和女士访问别墅
// villa.Accept(child).VisitEnd();
// villa.Accept(woman).VisitEnd();

// ************* 16.建造者模式测试 **************
// using BuilderPattern;

// MalePlayerBuilder maleBuilder = new MalePlayerBuilder();
// FemalePlayerBuilder femaleBuilder = new FemalePlayerBuilder();

// // 分别构建一个男性角色和女性角色
// PlayerBuilderDirector maleDirector = new PlayerBuilderDirector(maleBuilder);
// Player male = maleDirector.GetPlayer();
// PlayerBuilderDirector femaleDirector = new PlayerBuilderDirector(femaleBuilder);
// Player female = femaleDirector.GetPlayer();

// // 输出两个角色的信息
// Console.WriteLine(male);
// Console.WriteLine(female);

// ************* 17.适配器模式测试 **************
// using AdapterPattern;

// // 创建中文翻译器适配器以兼容客户端的接口
// ChineseTranslatorAdapter chineseTranslator = new ChineseTranslatorAdapter();

// // 模拟客户端的翻译请求
// Client client = new Client();
// client.Request("Hello world!", chineseTranslator);

// ************* 18.桥接模式测试 **************
// using BridgePattern;

// // 找两个模特
// Man jojo = new Man("JoJo");
// Man kaka = new Man("KaKa");

// // 做四种染色器
// RedDyer redDyer = new RedDyer(Color.Red);
// OrangeDyer orangeDyer = new OrangeDyer(Color.Orange);
// PurpleDyer purpleDyer = new PurpleDyer(Color.Purple);
// WhiteDyer whiteDyer = new WhiteDyer(Color.White);

// // 给四种衣服分别配置一种染色器
// Shirt whiteShirt = new Shirt("Shirt", "cotton", Season.Spring, whiteDyer);
// Sweater orangeSweater = new Sweater("Sweater", "polyester-fiber", Season.Autumn, orangeDyer);
// ShortSleeve purpleShortSleeve = new ShortSleeve("ShortSleeve", "cotton", Season.Summer, purpleDyer);
// Jacket redJacket = new Jacket("Jacket", "polyester-fiber and cotton", Season.Winter, redDyer);

// // 模特试穿衣服
// whiteShirt.Dressed(jojo);
// redJacket.Dressed(jojo);
// purpleShortSleeve.Dressed(kaka);
// orangeSweater.Dressed(kaka);

// ************* 19.命令模式测试 **************
// using CommandPattern;

// // 创建实例
// Light light = new Light();
// TurnOnLight turnOn = new TurnOnLight(light);
// TurnOffLight turnOff = new TurnOffLight(light);
// LightController controller = new LightController();

// // 开灯
// controller.SetCommand(turnOn);
// controller.PressButton();
// Console.WriteLine("Light is On:" + light.isOn);

// // 关灯
// controller.SetCommand(turnOff);
// controller.PressButton();
// Console.WriteLine("Light is On:" + light.isOn);

// ************* 20.原型模式测试 **************
// using PrototypePattern;
// #pragma warning disable

// // 创建实例
// Cube cube = new Cube("Default Cube");
// Sphere sphere = new Sphere("Default Sphere");
// _3DObjectManager manager = new _3DObjectManager();

// // 向3D原型对象管理器注册立方体和球体的原型对象
// manager.Register(cube, _3DObjectType.Cube);
// manager.Register(sphere, _3DObjectType.Sphere);

// // 从3D原型对象管理器获取立方体和球体的克隆对象
// Cube cube1 = manager.Get3DObject(_3DObjectType.Cube) as Cube;
// Sphere sphere1 = manager.Get3DObject(_3DObjectType.Sphere) as Sphere;

// // 输出立方体以及球体的原型和克隆对象的信息
// Console.WriteLine(cube);
// Console.WriteLine(cube1);
// Console.WriteLine(sphere);
// Console.WriteLine(sphere1);

// ************* 21.备忘录模式测试 **************
// using System.Text;
// using MementoPattern;

// // 创建实例
// TextEditor textEditor = new TextEditor();
// StringBuilder text = new StringBuilder("Hello world!");

// // 保存文本并输出文本
// textEditor.Save(text);
// Console.WriteLine(text);

// // 向文本添加内容并输出文本
// text.Append(" I am Jack.");
// Console.WriteLine(text);

// // 撤销文本操作并输出文本
// textEditor.Undo(text);
// Console.WriteLine(text);

// ************* 22.模板方法模式测试 **************
// using TemplateMethodPattern;

// // 创建实例
// Juice juice = new Juice();
// Tea tea = new Tea();

// // 制作果汁
// juice.MakeBeverage();

// // 制作茶
// tea.MakeBeverage();

// ************* 23.状态模式测试 **************
// using StatePattern;

// // 创建实例
// Light light = new Light();

// // 输出灯当前的状态
// Console.WriteLine("Light state:" + light.state);

// // 开灯并输出灯当前的状态
// light.ChangeState(LightState.TurnOn);
// Console.WriteLine("Light state:" + light.state);

// // 关灯并输出灯当前的状态
// light.ChangeState(LightState.TurnOff);
// Console.WriteLine("Light state:" + light.state);