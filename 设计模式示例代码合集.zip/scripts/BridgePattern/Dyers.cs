
namespace BridgePattern;

// 染色器
abstract class ColorDyer
{
    public Color color; // 颜色

    public ColorDyer(Color color)
    {
        this.color = color;
    }

    // 染色
    public abstract void Dye();
}

// 红色染色器
class RedDyer : ColorDyer
{
    public RedDyer(Color color) : base(color) { }

    public override void Dye()
    {
        Console.WriteLine("The dress is dyed red.");
    }
}

// 橙色染色器
class OrangeDyer : ColorDyer
{
    public OrangeDyer(Color color) : base(color) { }

    public override void Dye()
    {
        Console.WriteLine("The dress is dyed orange.");
    }
}

// 紫色染色器
class PurpleDyer : ColorDyer
{
    public PurpleDyer(Color color) : base(color) { }

    public override void Dye()
    {
        Console.WriteLine("The dress is dyed purple.");
    }
}

// 白色染色器
class WhiteDyer : ColorDyer
{
    public WhiteDyer(Color color) : base(color) { }

    public override void Dye()
    {
        Console.WriteLine("The dress is dyed white.");
    }
}