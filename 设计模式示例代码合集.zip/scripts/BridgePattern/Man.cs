
namespace BridgePattern;

// 男士模特
public class Man
{
    public string name; // 名字

    public Man(string name)
    {
        this.name = name;
    }

    // 行走
    public void Walk()
    {
        Console.WriteLine("The man named " + name + " is walking.");
        Thread.Sleep(new Random().Next(3000));
    }
}