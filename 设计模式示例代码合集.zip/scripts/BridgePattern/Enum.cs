
namespace BridgePattern;

//季节
enum Season
{
    Spring, Summer, Autumn, Winter
}

//颜色
enum Color
{
    Red, Blue, Orange, White, Black, Yellow, Green, Purple
}