
namespace BridgePattern;

// 衣服
abstract class Clothes
{
    public string name; // 衣服名称
    public string material; // 衣服材质
    public Season applicableSeason; // 适用季节
    protected ColorDyer colorDyer; // 染色器

    public Clothes(string name, string material, Season applicableSeason, ColorDyer colorDyer)
    {
        this.name = name;
        this.material = material;
        this.applicableSeason = applicableSeason;
        this.colorDyer = colorDyer;
    }

    // 给模特穿上
    public abstract void Dressed(Man man);
}

// 衬衫
class Shirt : Clothes
{
    public Shirt(string name, string material, Season applicableSeason, ColorDyer colorDyer) :
    base(name, material, applicableSeason, colorDyer)
    { }

    public override void Dressed(Man man)
    {
        Console.WriteLine("------------------------------------");
        colorDyer.Dye();
        Console.WriteLine(man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
    }
}

// 毛衣
class Sweater : Clothes
{
    public Sweater(string name, string material, Season applicableSeason, ColorDyer colorDyer) :
    base(name, material, applicableSeason, colorDyer)
    { }

    public override void Dressed(Man man)
    {
        Console.WriteLine("------------------------------------");
        colorDyer.Dye();
        Console.WriteLine(man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
    }
}

// 短袖
class ShortSleeve : Clothes
{
    public ShortSleeve(string name, string material, Season applicableSeason, ColorDyer colorDyer) :
    base(name, material, applicableSeason, colorDyer)
    { }

    public override void Dressed(Man man)
    {
        Console.WriteLine("------------------------------------");
        colorDyer.Dye();
        Console.WriteLine(man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
    }
}

// 夹克
class Jacket : Clothes
{
    public Jacket(string name, string material, Season applicableSeason, ColorDyer colorDyer) :
    base(name, material, applicableSeason, colorDyer)
    { }

    public override void Dressed(Man man)
    {
        Console.WriteLine("------------------------------------");
        colorDyer.Dye();
        Console.WriteLine(man.name + " is wearing a " + colorDyer.color + " " + name + " made of " + material + " which is suitable for " + applicableSeason + " wear.");
    }
}