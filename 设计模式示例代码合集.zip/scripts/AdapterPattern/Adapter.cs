
namespace AdapterPattern;

// 中文翻译器适配器
class ChineseTranslatorAdapter : ITranslator
{
    private ChineseTranslator chineseTranslator; // 中文翻译器

    public ChineseTranslatorAdapter()
    {
        chineseTranslator = new ChineseTranslator();
    }

    public string Translate(string text)
    {
        return chineseTranslator.TranslateToChinese(text);
    }
}