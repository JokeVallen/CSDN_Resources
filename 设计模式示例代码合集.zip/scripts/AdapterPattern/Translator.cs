
namespace AdapterPattern;

// 翻译器
interface ITranslator
{
    // 翻译
    string Translate(string text);
}

// 中文翻译器
class ChineseTranslator
{
    public string TranslateToChinese(string text)
    {
        return $"中文:请通过第三方翻译SDK将文本翻译成中文.(Text:{text})";
    }
}