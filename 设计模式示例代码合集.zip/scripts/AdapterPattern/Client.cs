
namespace AdapterPattern;

// 客户端
class Client
{
    // 翻译请求
    public void Request(string text, ITranslator translator)
    {
        Console.WriteLine(translator.Translate(text));
    }
}