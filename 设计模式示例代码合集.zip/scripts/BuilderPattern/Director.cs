
namespace BuilderPattern;

// 角色构建器指导者
class PlayerBuilderDirector
{
    private IPlayerBuilder playerBuilder; // 角色构建器

    public PlayerBuilderDirector(IPlayerBuilder playerBuilder)
    {
        this.playerBuilder = playerBuilder;
    }

    // 获取角色
    public Player GetPlayer()
    {
        playerBuilder.SetFacialFeatures();
        playerBuilder.SetClothing();
        return playerBuilder.Build();
    }
}