
namespace BuilderPattern;

// 角色构建器
interface IPlayerBuilder
{
    // 五官设置
    void SetFacialFeatures();
    // 穿着设置
    void SetClothing();
    // 构建
    Player Build();
}

// 男性角色构建器
class MalePlayerBuilder : IPlayerBuilder
{
    private Player player;

    public MalePlayerBuilder()
    {
        player = new Player();
    }

    public void SetFacialFeatures()
    {
        player.hair = "male hair";
        player.eyes = "male eyes";
        player.nose = "male nose";
        player.ears = "male ears";
        player.mouth = "male mouth";
    }

    public void SetClothing()
    {
        player.cloth = "male cloth";
        player.pants = "male pants";
        player.shoes = "male shoes";
    }

    public Player Build()
    {
        return player;
    }
}

// 女性角色构建器
class FemalePlayerBuilder : IPlayerBuilder
{
    private Player player;

    public FemalePlayerBuilder()
    {
        player = new Player();
    }

    public void SetFacialFeatures()
    {
        player.hair = "female hair";
        player.eyes = "female eyes";
        player.nose = "female nose";
        player.ears = "female ears";
        player.mouth = "female mouth";
    }

    public void SetClothing()
    {
        player.cloth = "female cloth";
        player.pants = "female pants";
        player.shoes = "female shoes";
    }

    public Player Build()
    {
        return player;
    }
}