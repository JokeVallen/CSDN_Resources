
namespace BuilderPattern;

// 角色
struct Player
{
    public string hair; // 头发
    public string eyes; // 眼睛
    public string nose; // 鼻子
    public string ears; // 耳朵
    public string mouth; // 嘴巴

    public string cloth; // 衣服
    public string pants; // 裤子
    public string shoes; // 鞋子

    public override string ToString()
    {
        return $"[Hair:{hair},Eyes:{eyes},Nose:{nose},Ears:{ears},Mouth:{mouth},Cloth:{cloth},Pants:{pants},Shoes:{shoes}]";
    }
}