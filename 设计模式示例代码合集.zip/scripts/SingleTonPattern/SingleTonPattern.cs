
namespace SingleTonPattern;

// 单例模式
class SingleTonPatternManager
{
    // 测试方法
    public void Test()
    {
        // 模拟多线程访问单例
        for (int i = 0; i < 30; i++)
        {
            Thread.Sleep(10);

            new Thread(() =>
            {
                SingleTon1 singleTon1 = SingleTon1.GetInstance();
                Console.WriteLine("singleTon1:" + singleTon1.GetHashCode());
            }).Start();

            new Thread(() =>
            {
                SingleTon2 singleTon2 = SingleTon2.GetInstance();
                Console.WriteLine("singleTon2:" + singleTon2.GetHashCode());
            }).Start();

            new Thread(() =>
            {
                SingleTon3 singleTon3 = SingleTon3.GetInstance();
                Console.WriteLine("singleTon3:" + singleTon3.GetHashCode());
            }).Start();
        }
    }

    // 单例模式：双重判空 + 锁 + 懒汉式加载
    class SingleTon1
    {
#pragma warning disable 8618
        private static SingleTon1 instance;
#pragma warning restore 8618
        private static readonly object k = new object();

        private SingleTon1() { }

        public static SingleTon1 GetInstance()
        {
            if (instance == null)
            {
                lock (k)
                {
                    if (instance == null) instance = new SingleTon1();
                }
            }
            return instance;
        }
    }

    // 单例模式：内部类 + 懒汉式加载
    class SingleTon2
    {
        private SingleTon2() { }

        private class Handler
        {
            public static readonly SingleTon2 instance = new SingleTon2();
        }

        public static SingleTon2 GetInstance()
        {
            return Handler.instance;
        }
    }

    // 单例模式：饿汉式加载
    class SingleTon3
    {
        private readonly static SingleTon3 instance = new SingleTon3();

        private SingleTon3() { }

        public static SingleTon3 GetInstance()
        {
            return instance;
        }
    }
}