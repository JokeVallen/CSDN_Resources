
namespace StatePattern;

// 灯
class Light
{
    // 灯的状态
    public LightState state { get; private set; }

    private ILightState turnOn; // 开灯状态
    private ILightState turnOff; //关灯状态

    public Light()
    {
        state = LightState.TurnOff;
        turnOn = new TurnOn();
        turnOff = new TurnOff();
    }

    // 改变灯的状态
    public void ChangeState(LightState lightState)
    {
        if (lightState == LightState.TurnOn) state = turnOn.Handle();
        else state = turnOff.Handle();
    }
}