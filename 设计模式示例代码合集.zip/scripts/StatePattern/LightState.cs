
namespace StatePattern;

// 灯的状态
enum LightState
{
    TurnOn, TurnOff
}

// 灯的状态接口
interface ILightState
{
    // 处理逻辑
    LightState Handle();
}

// 开灯状态
class TurnOn : ILightState
{
    public LightState Handle()
    {
        Console.WriteLine("正在开灯...");
        return LightState.TurnOn;
    }
}

// 关灯状态
class TurnOff : ILightState
{
    public LightState Handle()
    {
        Console.WriteLine("正在关灯...");
        return LightState.TurnOff;
    }
}