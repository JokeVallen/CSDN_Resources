
namespace CORPattern;

// 快捷键
enum Shortcut
{
    None, CTRL_X, CTRL_C, CTRL_V
}