
namespace CORPattern;

// 快捷键处理基类
abstract class ShortcutHandler
{
    protected ShortcutHandler nextHandler; // 下一个处理者

    public ShortcutHandler(ShortcutHandler nextHandler)
    {
        this.nextHandler = nextHandler;
    }

    public abstract void Handle(Shortcut shortcut); // 抽象方法：快捷键指令处理
}

// 剪切处理
class Cut : ShortcutHandler
{
    public Cut(ShortcutHandler nextHandler) : base(nextHandler) { }

    public override void Handle(Shortcut shortcut)
    {
        if (shortcut == Shortcut.CTRL_X) Console.WriteLine("Cut:已剪切文本...");
        else if (nextHandler != null) nextHandler.Handle(shortcut);
        else Console.WriteLine("Cut:责任链无法处理当前所指定的快捷键指令...");
    }
}

// 复制处理
class Copy : ShortcutHandler
{
    public Copy(ShortcutHandler nextHandler) : base(nextHandler) { }

    public override void Handle(Shortcut shortcut)
    {
        if (shortcut == Shortcut.CTRL_C) Console.WriteLine("Copy:已复制文本...");
        else if (nextHandler != null) nextHandler.Handle(shortcut);
        else Console.WriteLine("Copy:责任链无法处理当前所指定的快捷键指令...");
    }
}

// 粘贴处理
class Paste : ShortcutHandler
{
    public Paste(ShortcutHandler nextHandler) : base(nextHandler) { }

    public override void Handle(Shortcut shortcut)
    {
        if (shortcut == Shortcut.CTRL_V) Console.WriteLine("Paste:已粘贴文本...");
        else if (nextHandler != null) nextHandler.Handle(shortcut);
        else Console.WriteLine("Paste:责任链无法处理当前所指定的快捷键指令...");
    }
}