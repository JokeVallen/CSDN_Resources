
namespace DecoratorPattern;

// 武器
interface IWeapon
{
    string name { get; }
    void Operation();
}

// 剑
class Sword : IWeapon
{
    public string name => "Sword";

    public void Operation()
    {
        Console.WriteLine("Sword:This is a sword.");
    }
}

// 枪
class Gun : IWeapon
{
    public string name => "Gun";

    public void Operation()
    {
        Console.WriteLine("Gun:This is a gun.");
    }
}