
namespace DecoratorPattern;

// 武器装饰器
interface IWeaponDecorator : IWeapon { }

// 添加火焰属性
class FireDecorator : IWeaponDecorator
{
    public string name
    {
        get
        {
            if (weapon == null) return string.Empty;
            return weapon.name;
        }
    }

    private IWeapon weapon; // 武器

    public FireDecorator(IWeapon weapon)
    {
        this.weapon = weapon;
    }

    public void Operation()
    {
        Console.WriteLine($"Fire{name}:This is a {name} with the fire attribute.");
    }
}

// 添加红色属性
class RedDecorator : IWeaponDecorator
{
    public string name
    {
        get
        {
            if (weapon == null) return string.Empty;
            return weapon.name;
        }
    }

    private IWeapon weapon; // 武器

    public RedDecorator(IWeapon weapon)
    {
        this.weapon = weapon;
    }

    public void Operation()
    {
        Console.WriteLine($"Red{name}:This is a {name}, and it's color is red.");
    }
}