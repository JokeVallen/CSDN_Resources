
using System.Text;

namespace MementoPattern;

// 文本备忘录对象
class TextMemento
{
    // 文本内容
    public string text { get; private set; }

    public TextMemento(StringBuilder text)
    {
        this.text = text.ToString();
    }
}