
using System.Text;

namespace MementoPattern;

// 文本备忘录对象管理器
class MementoManager
{
    // 文本备忘录对象集合
    private Stack<TextMemento> mementos;

    public MementoManager()
    {
        mementos = new Stack<TextMemento>();
    }

    // 保存当前文本状态
    public void SaveState(StringBuilder text)
    {
        mementos.Push(new TextMemento(text));
    }

    // 回溯到上一个文本状态
    public void BackToPreState(StringBuilder text)
    {
        if (mementos.Count > 0)
        {
            text.Clear();
            text.Append(mementos.Pop().text);
        }
    }
}