
using System.Text;

namespace MementoPattern;

// 文本编辑器
class TextEditor
{
    private MementoManager manager; // 文本备忘录对象管理器

    public TextEditor()
    {
        manager = new MementoManager();
    }

    // 保存
    public void Save(StringBuilder text)
    {
        manager.SaveState(text);
    }

    // 撤销
    public void Undo(StringBuilder text)
    {
        manager.BackToPreState(text);
    }
}