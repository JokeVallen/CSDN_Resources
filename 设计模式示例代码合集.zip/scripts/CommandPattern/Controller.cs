
namespace CommandPattern;
#pragma warning disable

// 灯的开关控制按钮
class LightController
{
    private ICommand command;

    public LightController()
    {
        command = null;
    }

    // 设置按下按钮时执行的命令
    public void SetCommand(ICommand command)
    {
        this.command = command;
    }

    // 按下按钮
    public void PressButton()
    {
        if (command != null) command.Excute();
    }
}