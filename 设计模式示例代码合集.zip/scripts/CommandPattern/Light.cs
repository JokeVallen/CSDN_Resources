
namespace CommandPattern;

// 灯
class Light
{
    // 是否处于打开状态
    public bool isOn { get; private set; }

    // 打开
    public void TurnOn()
    {
        isOn = true;
        Console.WriteLine("开灯...");
    }

    // 关闭
    public void TurnOff()
    {
        isOn = false;
        Console.WriteLine("关灯...");
    }
}