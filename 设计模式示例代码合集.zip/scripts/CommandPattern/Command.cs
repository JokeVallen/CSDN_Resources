
namespace CommandPattern;

// 命令
interface ICommand
{
    // 执行
    void Excute();
}

// 开灯
class TurnOnLight : ICommand
{
    private Light light; // 灯

    public TurnOnLight(Light light)
    {
        this.light = light;
    }

    public void Excute()
    {
        light.TurnOn();
    }
}

// 关灯
class TurnOffLight : ICommand
{
    private Light light; // 灯

    public TurnOffLight(Light light)
    {
        this.light = light;
    }

    public void Excute()
    {
        light.TurnOff();
    }
}