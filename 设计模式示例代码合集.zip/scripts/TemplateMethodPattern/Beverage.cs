
namespace TemplateMethodPattern;

// 果汁
class Juice : BeverageTemplate
{
    public Juice()
    {
        name = "果汁";
    }

    protected override void Prepare()
    {
        Console.WriteLine($"{name}正在冲调...");
    }

    protected override void AddCondiments()
    {
        Console.WriteLine($"{name}正在加入调味品...");
    }
}

// 茶
class Tea : BeverageTemplate
{
    public Tea()
    {
        name = "茶";
    }

    protected override void Prepare()
    {
        Console.WriteLine($"{name}正在冲调...");
    }

    protected override void AddCondiments()
    {
        Console.WriteLine($"{name}正在加入调味品...");
    }
}