
namespace TemplateMethodPattern;

// 制作饮品的模板
abstract class BeverageTemplate
{
    protected string name; // 饮品名称

    public BeverageTemplate()
    {
        name = "饮品";
    }

    // 制作饮品
    public void MakeBeverage()
    {
        BoilWater();
        Prepare();
        AddCondiments();
        PutIntoCup();
        Console.WriteLine($"{name}制作完成了!");
        Console.WriteLine(new string('-', 20));
    }

    // 烧水
    protected void BoilWater()
    {
        Console.WriteLine("正在烧水...");
    }

    // 装杯
    protected void PutIntoCup()
    {
        Console.WriteLine($"{name}正在装入杯中...");
    }

    // 冲调
    protected abstract void Prepare();

    // 加入调味品
    protected abstract void AddCondiments();
}