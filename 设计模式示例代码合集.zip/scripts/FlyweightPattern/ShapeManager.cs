
namespace FlyweightPattern;

// 图形管理器
class ShapeManager
{
    private Dictionary<ShapeType, Shape> shapes; // 图形集合

    public ShapeManager()
    {
        shapes = new Dictionary<ShapeType, Shape>();
    }

    // 获取指定类型的图形
    public Shape GetShape(ShapeType shapeType)
    {
        if (!shapes.ContainsKey(shapeType))
        {
            switch (shapeType)
            {
                case ShapeType.Circle:
                    shapes[shapeType] = new Circle(shapeType);
                    break;
                case ShapeType.Rectangle:
                    shapes[shapeType] = new Rectangle(shapeType);
                    break;
                default:
                    Console.WriteLine("Warning:The type of shape doesn't exist.");
                    break;
            }
        }
        return shapes[shapeType];
    }
}