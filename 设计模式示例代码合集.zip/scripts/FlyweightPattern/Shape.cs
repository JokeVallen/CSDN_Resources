
namespace FlyweightPattern;

// 图形类型
enum ShapeType
{
    Circle, Rectangle
}

// 图形
abstract class Shape
{
    protected ShapeType shapeType; // 图形的类型

    public Shape(ShapeType shapeType)
    {
        this.shapeType = shapeType;
    }

    public abstract void Draw(string color); // 根据指定颜色进行绘制
}

// 圆
class Circle : Shape
{
    public Circle(ShapeType shapeType) : base(shapeType) { }

    public override void Draw(string color)
    {
        if (string.IsNullOrEmpty(color)) Console.WriteLine($"Circle:Drawing a circle.(HashCode:{GetHashCode()})");
        else Console.WriteLine($"Circle:Drawing a circle with {color} color.(HashCode:{GetHashCode()})");
    }
}

// 矩形
class Rectangle : Shape
{
    public Rectangle(ShapeType shapeType) : base(shapeType) { }

    public override void Draw(string color)
    {
        if (string.IsNullOrEmpty(color)) Console.WriteLine($"Rectangle:Drawing a rectangle.(HashCode:{GetHashCode()})");
        else Console.WriteLine($"Rectangle:Drawing a rectangle with {color} color.(HashCode:{GetHashCode()})");
    }
}