
namespace FactoryPattern;

// 主板
public interface IMotherBoard
{
    void OperationMB();
}

// 屏幕
public interface IScreen
{
    void OperationSC();
}

// 手机配件
public interface IPhoneAccessory
{
    void OperationPA();
}

// 手机主板
public class PhoneMotherBoard : IPhoneAccessory, IMotherBoard
{
    public void OperationMB()
    {
        Console.WriteLine("OperationMB:This is a PhoneMotherBoard.");
    }

    public void OperationPA()
    {
        Console.WriteLine("OperationPA:This is a PhoneMotherBoard.");
    }
}

// 手机屏幕
public class PhoneScreen : IPhoneAccessory, IScreen
{
    public void OperationPA()
    {
        Console.WriteLine("OperationPA:This is a PhoneScreen.");
    }

    public void OperationSC()
    {
        Console.WriteLine("OperationSC:This is a PhoneScreen.");
    }
}

// 电脑配件
public interface IComputerAccessory
{
    void OperationCA();
}

// 电脑主板
public class ComputerMotherBoard : IComputerAccessory, IMotherBoard
{
    public void OperationCA()
    {
        Console.WriteLine("OperationCA:This is a ComputerMotherBoard.");
    }

    public void OperationMB()
    {
        Console.WriteLine("OperationMB:This is a ComputerMotherBoard.");
    }
}

// 电脑屏幕
public class ComputerScreen : IComputerAccessory, IScreen
{
    public void OperationCA()
    {
        Console.WriteLine("OperationCA:This is a ComputerScreen.");
    }

    public void OperationSC()
    {
        Console.WriteLine("OperationSC:This is a ComputerScreen.");
    }
}