
namespace FactoryPattern;

// 抽象工厂接口
interface IFactory
{
    IMotherBoard CreateMB(); // 生产主板
    IScreen CreateSC(); // 生产屏幕
}

// 抽象工厂模式
class AbstractFactoryPattern
{
    // 电脑配件工厂
    public class MotherBoardFactory : IFactory
    {
        // 生产电脑主板
        public IMotherBoard CreateMB()
        {
            return new ComputerMotherBoard();
        }

        // 生产电脑屏幕
        public IScreen CreateSC()
        {
            return new ComputerScreen();
        }
    }

    // 手机配件工厂
    public class ScreenFactory : IFactory
    {
        // 生产手机主板
        public IMotherBoard CreateMB()
        {
            return new PhoneMotherBoard();
        }

        // 生产手机屏幕
        public IScreen CreateSC()
        {
            return new PhoneScreen();
        }
    }
}