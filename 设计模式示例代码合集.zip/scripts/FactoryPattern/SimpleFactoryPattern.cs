
namespace FactoryPattern;

// 简单工厂模式
class SimpleFactory
{
    // 配件工厂
    public class AccessoryFactory
    {
        // 生产手机主板
        public PhoneMotherBoard CreatePMB()
        {
            return new PhoneMotherBoard();
        }

        // 生产电脑主板
        public ComputerMotherBoard CreateCMB()
        {
            return new ComputerMotherBoard();
        }

        // 生产手机屏幕
        public PhoneScreen CreatePS()
        {
            return new PhoneScreen();
        }

        // 生产电脑屏幕
        public ComputerScreen CreateCS()
        {
            return new ComputerScreen();
        }
    }
}