
namespace FactoryPattern;

// 工厂方法接口
interface IFactoryMethod
{
    IPhoneAccessory Create();
}

// 工厂方法模式
class FactoryMethodPattern
{
    // 手机主板工厂
    public class PhoneMotherBoardFactory : IFactoryMethod
    {
        // 生产手机主板
        public IPhoneAccessory Create()
        {
            return new PhoneMotherBoard();
        }
    }

    // 手机屏幕工厂
    public class PhoneScreenFactory : IFactoryMethod
    {
        // 生产手机屏幕
        public IPhoneAccessory Create()
        {
            return new PhoneScreen();
        }
    }
}