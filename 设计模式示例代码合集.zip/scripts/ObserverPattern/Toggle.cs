
namespace ObserverPattern;

// UI控件状态（激活、禁用）
enum UIItemState
{
    Enabled, Disabled
}

// UI控件接口
interface IUIItem
{
    // UI控件状态
    UIItemState state { get; set; }

    // 注册观察者
    void Register(IObserve observe);

    // 注销观察者
    void UnRegister(IObserve observe);
}

// Toggle切换控件
class Toggle : IUIItem
{
    public UIItemState state
    {
        get { return _state; }
        set
        {
            if (_state != value)
            {
                _state = value;
                NotifyObservers();
            }
        }
    }

    private List<IObserve> observes; // 观察者集合
    private UIItemState _state; // Toggle组件的状态

    public Toggle()
    {
        observes = new List<IObserve>();
        _state = UIItemState.Enabled;
    }

    public void Register(IObserve observe)
    {
        observes.Add(observe);
    }

    public void UnRegister(IObserve observe)
    {
        observes.Remove(observe);
    }

    // 通知所有注册的观察者
    private void NotifyObservers()
    {
        for (int i = 0; i < observes.Count; i++)
        {
            observes[i].Handle(_state);
        }
    }
}