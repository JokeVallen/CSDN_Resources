
namespace ObserverPattern;

// 观察接口
interface IObserve
{
    // 当观察的UI控件的状态发生变化时的处理
    void Handle(UIItemState state);
}

// 窗口A
class WindowA : IObserve
{
    public void Handle(UIItemState state)
    {
        if (state == UIItemState.Enabled)
            Console.WriteLine("WindowA:The toggle's state is enabled, you have switched to Window A.");
    }
}

// 窗口B
class WindowB : IObserve
{
    public void Handle(UIItemState state)
    {
        if (state == UIItemState.Disabled)
            Console.WriteLine("WindowB:The toggle's state is disabled, you have switched to Window B.");
    }
}