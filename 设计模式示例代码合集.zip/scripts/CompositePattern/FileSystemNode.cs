
namespace CompositePattern;

// 文件系统节点
abstract class FileSystemNode
{
    protected string name; // 名称

    public FileSystemNode(string name)
    {
        this.name = name;
    }

    // 显示，level代表文件系统节点所在层级，根节点为1，根节点的一级子节点则为2，依次类推
    public abstract void Show(int level);
}

// 文件
class File : FileSystemNode
{
    public File(string name) : base(name) { }

    public override void Show(int level)
    {
        Console.WriteLine(new string('-', level) + name);
    }
}

// 文件夹
class Directory : FileSystemNode
{
    private List<FileSystemNode> fileSystemNodes; // 文件系统节点集合

    public Directory(string name) : base(name)
    {
        fileSystemNodes = new List<FileSystemNode>();
    }

    // 添加文件系统节点
    public void Add(FileSystemNode fileSystemNode)
    {
        fileSystemNodes.Add(fileSystemNode);
    }

    // 移除文件系统节点
    public void Remove(FileSystemNode fileSystemNode)
    {
        fileSystemNodes.Remove(fileSystemNode);
    }

    public override void Show(int level)
    {
        Console.WriteLine(new string('-', level) + name);
        for (int i = 0; i < fileSystemNodes.Count; i++)
        {
            fileSystemNodes[i].Show(level + 1);
        }
    }
}