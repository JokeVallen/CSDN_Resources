
namespace MediatorPattern;

// 聊天室中介者
interface IChatroomMediator
{
    void SendMessage(string message, IChat user);
    void Register(IChat user);
}

// 聊天室
class Chatroom : IChatroomMediator
{
    private List<IChat> users; // 用户集合

    public Chatroom()
    {
        users = new List<IChat>();
    }

    // 注册用户
    public void Register(IChat user)
    {
        users.Add(user);
    }

    // 指定用户向其他用户发送指定信息
    public void SendMessage(string message, IChat user)
    {
        if (users.Count == 0) return;
        for (int i = 0; i < users.Count; i++)
        {
            if (users[i] != user) users[i].ReceiveMessage(message);
        }
    }
}