
namespace MediatorPattern;

// 聊天接口
interface IChat
{
    void SendMessage(string message);
    void ReceiveMessage(string message);
}

// 同事
class Colleague : IChat
{
    private string name; // 名称
    private IChatroomMediator chatroom; // 聊天室

    public Colleague(string name, IChatroomMediator chatroom)
    {
        this.name = name;
        this.chatroom = chatroom;
        chatroom.Register(this); // 向聊天室进行注册
    }

    // 发送消息
    public void SendMessage(string message)
    {
        chatroom.SendMessage($"{name}:" + message, this);
    }

    // 接收消息
    public void ReceiveMessage(string message)
    {
        Console.WriteLine($"User '{name}' received a message with the content '{message}'.");
    }
}