
namespace IteratorPattern;

// 集合元素
struct CollectionItem
{
    public int value; // 集合元素的值

    public CollectionItem(int value)
    {
        this.value = value;
    }

    public override string ToString()
    {
        return "value:" + value;
    }
}

// 集合迭代器
class CollectionIterator : IIterator
{
    public object next
    {
        get
        {
            try
            {
                return collectionItems[index++];
            }
            catch (IndexOutOfRangeException)
            {
                throw new InvalidOperationException();
            }
        }
    }

    private CollectionItem[] collectionItems; // 集合元素合集
    private int index; // 当前所访问元素的索引

    public CollectionIterator(CollectionItem[] collectionItems)
    {
        this.collectionItems = collectionItems;
        index = 0;
    }

    public bool HasNext()
    {
        return index < collectionItems.Length;
    }
}

// 集合
class Collection : Iterable
{
    private CollectionItem[] collectionItems; // 集合元素合集

    public Collection(CollectionItem[] collectionItems)
    {
        if (collectionItems == null || collectionItems.Length == 0)
        {
            this.collectionItems = Array.Empty<CollectionItem>();
        }
        else
        {
            this.collectionItems = new CollectionItem[collectionItems.Length];
            Array.Copy(collectionItems, this.collectionItems, collectionItems.Length);
        }
    }

    public IIterator GetIterator()
    {
        return new CollectionIterator(collectionItems);
    }
}