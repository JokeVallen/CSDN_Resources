
namespace IteratorPattern;

// 迭代器接口
interface IIterator
{
    // 是否存在下一个元素
    bool HasNext();
    // 下一个元素
    object next { get; }
}

// 可迭代接口
interface Iterable
{
    // 获取迭代器
    IIterator GetIterator();
}