
namespace StrategyPattern;

// 策略
interface IStrategy
{
    // 约定返回结果：-1表示a劣于b，0表示a与b平等，1表示a优于b
    int Compare(Animal a, Animal b);
}

// 体重比较策略
class WeightStrategy : IStrategy
{
    public int Compare(Animal a, Animal b)
    {
        if (a != null && b != null)
        {
            // 动物a的体重低于动物b
            if (a.weight < b.weight) return -1;
            // 动物a的体重高于动物b
            if (a.weight > b.weight) return 1;
        }
        return 0;
    }
}

// 长度比较策略
class LengthStrategy : IStrategy
{
    public int Compare(Animal a, Animal b)
    {
        if (a != null && b != null)
        {
            // 动物a的长度小于动物b
            if (a.length < b.length) return -1;
            // 动物a的长度大于动物b
            if (a.length > b.length) return 1;
        }
        return 0;
    }
}