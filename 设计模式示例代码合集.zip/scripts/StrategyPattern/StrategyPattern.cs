
namespace StrategyPattern;

// 策略模式
class StrategyPatternManager
{
    private IStrategy strategy;

    public StrategyPatternManager(IStrategy strategy)
    {
        this.strategy = strategy;
    }

    public void Sort(Animal[] animals, bool minToMax = true)
    {
        // 符合以下判断则不进行排序
        if (strategy == null || animals == null || animals.Length == 0) return;

        // res用于记录比较策略的结果值，1表示从小到大排序，-1表示从大到小排序
        int res = 1;
        if (!minToMax) res = -1;

        // 冒泡排序
        for (int i = 0; i < animals.Length; i++)
        {
            for (int j = i + 1; j < animals.Length; j++)
            {
                if (strategy.Compare(animals[i], animals[j]) == res)
                {
                    Animal temp = animals[i];
                    animals[i] = animals[j];
                    animals[j] = temp;
                }
            }
        }
    }
}