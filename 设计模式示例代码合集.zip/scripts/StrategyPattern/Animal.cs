
namespace StrategyPattern;

// 动物
class Animal
{
    public string name; // 动物名称
    public float weight; // 动物体重，单位kg
    public float length; // 动物从头部到尾部的长度，单位m

    public Animal(string name, float weight, float length)
    {
        this.name = name;
        this.weight = weight;
        this.length = length;
    }

    public override string ToString()
    {
        return $"[name:{name},weight:{weight},length:{length}]";
    }
}

// 猫
class Cat : Animal
{
    public Cat(string name, float weight, float length) : base(name, weight, length) { }
}