
namespace ProxyPattern;

// 调试接口
interface IDebug
{
    // 控制台输出
    void Log(string content);
}

// 调试
class Debug : IDebug
{
    public void Log(string content)
    {
        Console.WriteLine(content);
    }
}

// 调试代理
class DebugProxy : IDebug
{
    private Debug debug;

    public DebugProxy()
    {
        debug = new Debug();
    }

    public void Log(string content)
    {
        Console.WriteLine("---------------- Begin ----------------");
        debug.Log(content);
        Console.WriteLine("----------------  End  ----------------");
    }
}