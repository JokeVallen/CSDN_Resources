
namespace FacadePattern;

// 订单系统
class OrderSystem
{
    public void SubmitOrder()
    {
        Console.WriteLine("已发送订单给商家。");
    }

    public void CancleOrder()
    {
        Console.WriteLine("已取消订单，并告知商家。");
    }
}

// 物流系统
class LogisticsSystem
{
    public void SendGood()
    {
        Console.WriteLine("商家已发送货物。");
    }

    public void StopSendGood()
    {
        Console.WriteLine("商家已停止发送货物。");
    }
}

// 支付系统
class PaymentSystem
{
    public void Pay()
    {
        Console.WriteLine("顾客已支付订单。");
    }

    public void ReturnMoney()
    {
        Console.WriteLine("支付款已退还给顾客。");
    }
}