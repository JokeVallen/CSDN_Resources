
namespace FacadePattern;

// 门面模式
class FacadePatternManager
{
    private OrderSystem orderSystem;
    private LogisticsSystem logisticsSystem;
    private PaymentSystem paymentSystem;

    public FacadePatternManager()
    {
        orderSystem = new OrderSystem();
        logisticsSystem = new LogisticsSystem();
        paymentSystem = new PaymentSystem();
    }

    // 完成商品购买
    public void Shopping()
    {
        paymentSystem.Pay();
        orderSystem.SubmitOrder();
        logisticsSystem.SendGood();
    }

    // 取消商品购买
    public void Cancle()
    {
        orderSystem.CancleOrder();
        logisticsSystem.StopSendGood();
        paymentSystem.ReturnMoney();
    }
}