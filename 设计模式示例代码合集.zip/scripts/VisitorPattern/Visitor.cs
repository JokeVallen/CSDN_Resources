
namespace VisitorPattern;

// 访客
interface IVisitor
{
    // 访客名称
    string name { get; }
    // 看看厨房
    void VisitKitchen();
    // 看看厕所
    void VisitToilet();
    // 看看卧室
    void VisitBedroom();
    // 到处看看
    void Visit();
    // 看完了，该走了
    void VisitEnd();
}

// 儿童
class Child : IVisitor
{
    public string name => _name;
    private string _name;

    public Child(string name)
    {
        _name = name;
    }

    public void Visit()
    {
        VisitBedroom();
        VisitKitchen();
        VisitToilet();
    }

    public void VisitBedroom()
    {
        Console.WriteLine($"The child {_name} plays in the bedroom.");
    }

    public void VisitEnd()
    {
        Console.WriteLine("-----------------------------------");
    }

    public void VisitKitchen()
    {
        Console.WriteLine($"The child {_name} feels hungry, so he wants to find some foods to eat in the kitchen.");
    }

    public void VisitToilet()
    {
        Console.WriteLine($"Beacuse of drinking much juice, the child {_name} wants to return to nature.");
    }

}

// 女士
class Woman : IVisitor
{
    public string name => _name;
    private string _name;

    public Woman(string name)
    {
        _name = name;
    }

    public void Visit()
    {
        VisitToilet();
        VisitBedroom();
        VisitKitchen();
    }

    public void VisitEnd()
    {
        Console.WriteLine("-----------------------------------");
    }

    public void VisitBedroom()
    {
        Console.WriteLine($"The woman {_name} feels sleepy so that she is fast asleep in the bedroom.");
    }

    public void VisitKitchen()
    {
        Console.WriteLine($"The woman {_name} feels a little hungry after a sleep and she find some cookies in the refrigerator of kitchen luckily.");
    }

    public void VisitToilet()
    {
        Console.WriteLine($"The woman {_name} wants to return to nature beacuse of drinking much wine last night.");
    }
}