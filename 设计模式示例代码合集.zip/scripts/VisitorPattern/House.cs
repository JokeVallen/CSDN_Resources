
namespace VisitorPattern;

// 房屋结构
abstract class HousePart
{
    public string name; // 房屋结构名称

    public HousePart(string name)
    {
        this.name = name;
    }

    public abstract void Introduce(); // 介绍房屋结构
}

// 房屋
abstract class House
{
    protected string name; // 房屋名称
    protected HousePart kitchen; // 厨房
    protected HousePart toilet; // 厕所
    protected HousePart bedroom; // 卧室

    public House(string name, HousePart kitchen, HousePart toilet, HousePart bedroom)
    {
        this.name = name;
        this.kitchen = kitchen;
        this.toilet = toilet;
        this.bedroom = bedroom;
    }

    protected abstract void WelcomeAndIntroduce(IVisitor visitor); // 欢迎访客并介绍房屋结构
    public abstract IVisitor Accept(IVisitor visitor); // 接收访客的访问
}

// 公寓 
class Apartment : House
{
    public Apartment(string name, HousePart kitchen, HousePart toilet, HousePart bedroom) :
    base(name, kitchen, toilet, bedroom)
    { }

    public override IVisitor Accept(IVisitor visitor)
    {
        WelcomeAndIntroduce(visitor);
        visitor.Visit();
        return visitor;
    }

    protected override void WelcomeAndIntroduce(IVisitor visitor)
    {
        Console.WriteLine($"Hello {visitor.name}, welcome to my {name}.");
        kitchen.Introduce();
        bedroom.Introduce();
        toilet.Introduce();
    }
}

// 别墅
class Villa : House
{
    public Villa(string name, HousePart kitchen, HousePart toilet, HousePart bedroom) :
    base(name, kitchen, toilet, bedroom)
    { }

    public override IVisitor Accept(IVisitor visitor)
    {
        WelcomeAndIntroduce(visitor);
        visitor.Visit();
        return visitor;
    }

    protected override void WelcomeAndIntroduce(IVisitor visitor)
    {
        Console.WriteLine($"Hello {visitor.name}, welcome to my {name}.");
        kitchen.Introduce();
        bedroom.Introduce();
        toilet.Introduce();
    }
}

// 厨房
class Kitchen : HousePart
{
    public Kitchen(string name) : base(name) { }
    public override void Introduce()
    {
        Console.WriteLine($"Welcome to {name}. This is a place for cooking.");
    }
}

// 厕所
class Toilet : HousePart
{
    public Toilet(string name) : base(name) { }
    public override void Introduce()
    {
        Console.WriteLine($"Welcome to {name}. This is a place to return to nature.");
    }
}

// 卧室
class Bedroom : HousePart
{
    public Bedroom(string name) : base(name) { }
    public override void Introduce()
    {
        Console.WriteLine($"Welcome to {name}. This is a place to sleep.");
    }
}