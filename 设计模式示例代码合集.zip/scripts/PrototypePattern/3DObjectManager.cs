
namespace PrototypePattern;
#pragma warning disable

// 3D原型对象管理器
class _3DObjectManager
{
    private Dictionary<_3DObjectType, IPrototype> objects; // 3D原型对象集合

    public _3DObjectManager()
    {
        objects = new Dictionary<_3DObjectType, IPrototype>();
    }

    // 注册指定类型的3D原型对象
    public void Register(IPrototype _3dObject, _3DObjectType type)
    {
        objects[type] = _3dObject;
    }

    // 获取指定类型的3D原型对象的克隆对象
    public IPrototype Get3DObject(_3DObjectType type)
    {
        if (objects.ContainsKey(type)) return objects[type].Clone();
        return null;
    }
}