
namespace PrototypePattern;

// 原型
interface IPrototype
{
    // 克隆
    IPrototype Clone();
}

// 3D物体类型
enum _3DObjectType
{
    None, Cube, Sphere
}

// 3D物体
abstract class _3DObject : IPrototype
{
    public string name;
    public _3DObjectType type { get; protected set; }

    public _3DObject(string name)
    {
        this.name = name;
    }

    public abstract IPrototype Clone();
}

// 立方体
class Cube : _3DObject
{
    public Cube(string name) : base(name)
    {
        type = _3DObjectType.Cube;
    }

    public override IPrototype Clone()
    {
        return new Cube(name);
    }

    public override string ToString()
    {
        return $"[Name:{name},Type:{type},HashCode:{GetHashCode()}]";
    }
}

// 球体
class Sphere : _3DObject
{
    public Sphere(string name) : base(name)
    {
        type = _3DObjectType.Sphere;
    }

    public override IPrototype Clone()
    {
        return new Sphere(name);
    }

    public override string ToString()
    {
        return $"[Name:{name},Type:{type},HashCode:{GetHashCode()}]";
    }
}